/**
 * Vocabulário e opções do produto.
 * Linguagem obrigatória: acolhimento, compatibilidade e conexão.
 * Nunca usar termos de leilão/compra e venda de pessoas.
 */

export const NEEDS = [
  "ansiedade/estresse",
  "relacionamento",
  "terapia de casal",
  "luto",
  "autoestima",
  "família",
  "carreira",
  "adolescência",
  "questões emocionais",
  "outro",
] as const;

export const PROFESSIONAL_PREFERENCES = [
  "psicólogo homem",
  "psicóloga mulher",
  "indiferente",
] as const;

export const MODALITIES = ["online", "presencial", "indiferente"] as const;

export const AVAILABILITY_OPTIONS = [
  "manhã",
  "tarde",
  "noite",
  "finais de semana",
] as const;

export const START_INTENTS = [
  "agora",
  "esta semana",
  "próximas semanas",
  "estou apenas pesquisando",
] as const;

export const PRICE_RANGES = [
  "até R$100",
  "R$100–150",
  "R$150–200",
  "R$200–300",
  "acima de R$300",
] as const;

export const FREQUENCIES = ["semanal", "quinzenal", "ainda não sei"] as const;

export const AUDIENCES = [
  "adultos",
  "adolescentes",
  "idosos",
  "casais",
  "famílias",
] as const;

export const APPROACHES = [
  "TCC",
  "Psicanálise",
  "Sistêmica",
  "Humanista",
  "Gestalt",
  "ACT",
] as const;

export const PRICE_RANGE_BOUNDS: Record<string, { min: number; max: number }> = {
  "até R$100": { min: 0, max: 100 },
  "R$100–150": { min: 100, max: 150 },
  "R$150–200": { min: 150, max: 200 },
  "R$200–300": { min: 200, max: 300 },
  "acima de R$300": { min: 300, max: 500 },
};

export const FREQUENCY_SESSIONS_PER_YEAR: Record<string, number> = {
  semanal: 52,
  quinzenal: 26,
  "ainda não sei": 0,
};

export const LEAD_STATUS_LABELS: Record<string, string> = {
  NEW: "Novo",
  CONSENTED: "Consentimento registrado",
  QUALIFYING: "Em qualificação",
  QUALIFIED: "Qualificado",
  WARMING: "Em aquecimento",
  READY_FOR_MATCHING: "Pronto para conexão",
  OPPORTUNITY_CREATED: "Oportunidade criada",
  CONNECTED: "Conexão realizada",
  CONVERTED: "Atendimento iniciado",
  INVALID: "Inválido",
  UNRESPONSIVE: "Sem resposta",
  CANCELLED: "Cancelado",
};

export const OPPORTUNITY_STATUS_LABELS: Record<string, string> = {
  DRAFT: "Rascunho",
  OPEN: "Aberta",
  SELECTING: "Selecionando profissional",
  PROFESSIONAL_SELECTED: "Profissional selecionado",
  PAYMENT_PENDING: "Confirmação pendente",
  PAID: "Confirmada",
  CONTACT_UNLOCKED: "Contato liberado",
  CONNECTED: "Conexão realizada",
  EXPIRED: "Janela encerrada",
  NO_CANDIDATES: "Sem profissionais compatíveis",
  PAYMENT_EXPIRED: "Prazo de confirmação encerrado",
  CANCELLED: "Cancelada",
};

export const CONNECTION_STAGES = [
  "CONTACT_PENDING",
  "CONTACTED",
  "APPOINTMENT_SCHEDULED",
  "TREATMENT_STARTED",
  "NO_CONTACT",
  "GAVE_UP",
  "NOT_COMPATIBLE",
] as const;

export const CONNECTION_STAGE_LABELS: Record<string, string> = {
  CONNECTION_MADE: "Conexão realizada",
  CONTACT_PENDING: "Contato ainda não realizado",
  CONTACTED: "Contato realizado",
  APPOINTMENT_SCHEDULED: "Consulta agendada",
  TREATMENT_STARTED: "Paciente iniciou acompanhamento",
  NO_CONTACT: "Não consegui contato",
  GAVE_UP: "Pessoa desistiu",
  NOT_COMPATIBLE: "Não houve compatibilidade",
};

export const CONVERSION_EVENTS = [
  "LEAD_CREATED",
  "LEAD_QUALIFIED",
  "LEAD_WARMED",
  "OPPORTUNITY_CREATED",
  "INTEREST_RECEIVED",
  "PROFESSIONAL_SELECTED",
  "PAYMENT_COMPLETED",
  "CONTACT_UNLOCKED",
  "CONTACTED",
  "APPOINTMENT_SCHEDULED",
  "TREATMENT_STARTED",
] as const;

export const CREDIT_PACKAGES = [100, 250, 500, 1000];
export const PRIORITY_SUGGESTIONS = [80, 100, 120];

export function formatBRL(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
    maximumFractionDigits: 0,
  }).format(value);
}

/** Projeção de acompanhamento — nunca apresentar como garantia. */
export function estimateFollowUp(priceRange: string | null, frequency: string | null) {
  const bounds = priceRange ? PRICE_RANGE_BOUNDS[priceRange] : undefined;
  const sessions = frequency ? (FREQUENCY_SESSIONS_PER_YEAR[frequency] ?? 0) : 0;
  if (!bounds || !sessions) return null;
  return { min: bounds.min * sessions, max: bounds.max * sessions, sessions };
}

export const ESTIMATE_DISCLAIMER =
  "Estimativa baseada nas informações fornecidas pelo usuário. Não representa garantia de contratação, permanência ou faturamento.";
