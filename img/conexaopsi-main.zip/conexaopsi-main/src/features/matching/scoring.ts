/**
 * Motor de compatibilidade.
 * Regras de negócio ficam aqui (nunca dentro de componentes) e os pesos vêm
 * de platform_settings, para serem configuráveis no painel administrativo.
 */
import { PRICE_RANGE_BOUNDS } from "@/features/shared/domain";

export type MatchingWeights = {
  specialty: number;
  modality: number;
  availability: number;
  price: number;
  preferences: number;
  location: number;
  quality: number;
};

export type FinalScoreWeights = { compatibility: number; priority: number };

export const DEFAULT_MATCHING_WEIGHTS: MatchingWeights = {
  specialty: 25,
  modality: 15,
  availability: 15,
  price: 15,
  preferences: 10,
  location: 10,
  quality: 10,
};

export const DEFAULT_FINAL_SCORE_WEIGHTS: FinalScoreWeights = {
  compatibility: 0.8,
  priority: 0.2,
};

export type OpportunitySignals = {
  need: string;
  modality: string;
  city: string | null;
  state: string | null;
  professional_preference: string | null;
  availability: string[];
  price_range: string | null;
};

export type ProfessionalSignals = {
  specialties: string[];
  modalities: string[];
  online_care: boolean;
  city: string | null;
  state: string | null;
  gender: string | null;
  availability: string[];
  min_price: number | null;
  max_price: number | null;
  quality_score: number;
};

export type EligibilityResult = { eligible: boolean; reason?: string };

/** Filtro de elegibilidade — roda ANTES de qualquer pontuação. */
export function checkEligibility(
  opp: OpportunitySignals,
  pro: ProfessionalSignals,
): EligibilityResult {
  if (opp.modality === "online" && !pro.online_care && !pro.modalities.includes("online")) {
    return { eligible: false, reason: "Não atende no formato online" };
  }
  if (opp.modality === "presencial") {
    if (!pro.modalities.includes("presencial")) {
      return { eligible: false, reason: "Não atende presencialmente" };
    }
    if (opp.city && pro.city && normalize(opp.city) !== normalize(pro.city)) {
      return { eligible: false, reason: "Cidade diferente da informada" };
    }
  }
  if (
    opp.professional_preference === "psicóloga mulher" &&
    pro.gender &&
    pro.gender !== "feminino"
  ) {
    return { eligible: false, reason: "Preferência de profissional não atendida" };
  }
  if (
    opp.professional_preference === "psicólogo homem" &&
    pro.gender &&
    pro.gender !== "masculino"
  ) {
    return { eligible: false, reason: "Preferência de profissional não atendida" };
  }
  return { eligible: true };
}

export function compatibilityScore(
  opp: OpportunitySignals,
  pro: ProfessionalSignals,
  weights: MatchingWeights = DEFAULT_MATCHING_WEIGHTS,
): number {
  let score = 0;

  // Especialidade
  const needMatch = pro.specialties.some((s) => normalize(s) === normalize(opp.need));
  score += weights.specialty * (needMatch ? 1 : 0.35);

  // Modalidade
  const modalityMatch =
    opp.modality === "indiferente" ||
    pro.modalities.includes(opp.modality) ||
    (opp.modality === "online" && pro.online_care);
  score += weights.modality * (modalityMatch ? 1 : 0);

  // Disponibilidade
  const overlap = opp.availability.filter((a) => pro.availability.includes(a)).length;
  const availabilityRatio = opp.availability.length ? overlap / opp.availability.length : 0.5;
  score += weights.availability * availabilityRatio;

  // Faixa de investimento
  score += weights.price * priceFit(opp.price_range, pro.min_price, pro.max_price);

  // Preferências declaradas
  const prefMatch =
    !opp.professional_preference ||
    opp.professional_preference === "indiferente" ||
    (opp.professional_preference === "psicóloga mulher" && pro.gender === "feminino") ||
    (opp.professional_preference === "psicólogo homem" && pro.gender === "masculino");
  score += weights.preferences * (prefMatch ? 1 : 0);

  // Localização
  let locationRatio = 0.5;
  if (opp.modality === "online") locationRatio = 1;
  else if (opp.city && pro.city && normalize(opp.city) === normalize(pro.city)) locationRatio = 1;
  else if (opp.state && pro.state && opp.state === pro.state) locationRatio = 0.7;
  score += weights.location * locationRatio;

  // Qualidade do perfil profissional
  score += weights.quality * Math.min(1, Math.max(0, pro.quality_score / 100));

  return Math.round(Math.min(100, Math.max(0, score)));
}

function priceFit(range: string | null, min: number | null, max: number | null): number {
  if (!range || min == null || max == null) return 0.5;
  const bounds = PRICE_RANGE_BOUNDS[range];
  if (!bounds) return 0.5;
  const overlap = Math.min(bounds.max, max) - Math.max(bounds.min, min);
  if (overlap >= 0) return 1;
  const distance = Math.abs(overlap);
  return Math.max(0, 1 - distance / 150);
}

/**
 * Prioridade de conexão: influência limitada e configurável.
 * priorityScore é normalizado pelo maior investimento da oportunidade.
 */
export function finalScore(
  compatibility: number,
  priorityScore: number,
  weights: FinalScoreWeights = DEFAULT_FINAL_SCORE_WEIGHTS,
): number {
  return Number(
    (compatibility * weights.compatibility + priorityScore * weights.priority).toFixed(4),
  );
}

export function normalizePriority(amount: number, maxAmount: number): number {
  if (maxAmount <= 0) return 0;
  return Math.min(100, (amount / maxAmount) * 100);
}

function normalize(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
}
