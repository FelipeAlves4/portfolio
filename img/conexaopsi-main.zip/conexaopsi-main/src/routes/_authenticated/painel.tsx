import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/painel")({
  head: () => ({
    meta: [
      { title: "Painel do profissional — Conexão Psi" },
      {
        name: "description",
        content: "Acompanhe suas oportunidades de conexão e seus créditos na Conexão Psi.",
      },
      { property: "og:title", content: "Painel do profissional — Conexão Psi" },
      {
        property: "og:description",
        content: "Oportunidades de conexão compatíveis com o seu perfil profissional.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PainelPage,
});

function PainelPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="min-h-screen surface-calm">
      <main className="mx-auto w-full max-w-5xl px-4 py-12 sm:px-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-semibold">Painel do profissional</h1>
            <p className="mt-2 text-muted-foreground">
              Aqui você acompanha as oportunidades de conexão compatíveis com o seu perfil.
            </p>
          </div>
          <Button variant="outline" className="rounded-xl" onClick={signOut}>
            Sair
          </Button>
        </div>

        <div className="card-soft mt-8 p-8">
          <h2 className="text-lg font-semibold">Oportunidades de conexão</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Assim que houver uma pessoa compatível com o seu perfil, ela aparece aqui com as
            informações não identificáveis do Perfil de Conexão.
          </p>
        </div>
      </main>
    </div>
  );
}
