import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { SiteHeader } from "@/components/layout/SiteHeader";
import heroImage from "@/assets/hero-calm.jpg";
import {
  HeartHandshake,
  Laptop,
  Lock,
  MapPin,
  MessageCircle,
  ShieldCheck,
  Sparkles,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Conexão Psi — Encontre um psicólogo compatível com você" },
      {
        name: "description",
        content:
          "Conte o que você procura e encontramos profissionais compatíveis com suas necessidades, preferências e disponibilidade. Processo simples, acolhedor e privado.",
      },
      { property: "og:title", content: "Conexão Psi — Encontre um psicólogo compatível com você" },
      {
        property: "og:description",
        content:
          "Uma conversa rápida e cuidadosa para conectar você a profissionais compatíveis com o que você está procurando.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LandingPage,
});

const steps = [
  {
    icon: MessageCircle,
    title: "Conte o que você procura",
    description:
      "Algumas perguntas rápidas e acolhedoras sobre o que você busca, sua disponibilidade e suas preferências.",
  },
  {
    icon: Sparkles,
    title: "Encontramos profissionais compatíveis",
    description:
      "Analisamos especialidade, modalidade, horários e faixa de investimento para encontrar quem combina com você.",
  },
  {
    icon: HeartHandshake,
    title: "A conexão acontece",
    description:
      "O profissional selecionado entra em contato para conversar sobre o início do acompanhamento.",
  },
];

function LandingPage() {
  return (
    <div className="min-h-screen surface-calm">
      <SiteHeader />

      <main>
        <section className="mx-auto grid w-full max-w-6xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
          <div className="space-y-6">
            <span className="inline-flex items-center gap-2 rounded-full bg-accent px-4 py-1.5 text-xs font-medium text-accent-foreground">
              <HeartHandshake className="size-3.5" /> Cuidado que combina com você
            </span>
            <h1 className="text-4xl font-semibold leading-tight sm:text-5xl">
              Encontre um psicólogo que combine com o que você está procurando.
            </h1>
            <p className="max-w-xl text-lg text-muted-foreground">
              Conte para a gente um pouco sobre o que você busca e vamos encontrar profissionais
              compatíveis com suas necessidades, preferências e disponibilidade.
            </p>
            <div className="flex flex-col gap-3 sm:flex-row">
              <Button asChild size="lg" className="rounded-xl">
                <Link to="/qualificacao">Encontrar um profissional</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="rounded-xl">
                <Link to="/" hash="como-funciona">
                  Como funciona
                </Link>
              </Button>
            </div>
            <p className="flex items-center gap-2 text-sm text-muted-foreground">
              <Lock className="size-4" /> Suas informações são tratadas com sigilo e só são
              compartilhadas com a sua autorização.
            </p>
          </div>

          <div className="overflow-hidden rounded-3xl border border-border shadow-[var(--shadow-lift)]">
            <img
              src={heroImage}
              alt="Ambiente tranquilo e acolhedor com poltrona clara e luz natural suave"
              width={1600}
              height={1104}
              className="h-full w-full object-cover"
            />
          </div>
        </section>

        <section id="como-funciona" className="border-y border-border/60 bg-background/70 py-16">
          <div className="mx-auto w-full max-w-6xl px-4 sm:px-6">
            <h2 className="text-3xl font-semibold">Como funciona</h2>
            <p className="mt-2 max-w-2xl text-muted-foreground">
              Um processo simples, sem listas intermináveis de profissionais para você filtrar
              sozinho.
            </p>
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {steps.map((step) => (
                <article key={step.title} className="card-soft p-7">
                  <span className="surface-primary mb-5 flex size-11 items-center justify-center rounded-2xl">
                    <step.icon className="size-5 text-primary-foreground" />
                  </span>
                  <h3 className="text-lg font-semibold">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {step.description}
                  </p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="mx-auto grid w-full max-w-6xl gap-6 px-4 sm:px-6 md:grid-cols-2">
            <article className="card-soft p-8">
              <Laptop className="size-6 text-primary" />
              <h3 className="mt-4 text-xl font-semibold">Atendimento online</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                Sessões por vídeo, de onde você estiver, com profissionais que atendem no horário
                que funciona para a sua rotina.
              </p>
            </article>
            <article className="card-soft p-8">
              <MapPin className="size-6 text-primary" />
              <h3 className="mt-4 text-xl font-semibold">Atendimento presencial</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                Se você prefere o encontro presencial, consideramos sua cidade e região para
                encontrar profissionais compatíveis.
              </p>
            </article>
          </div>
        </section>

        <section id="privacidade" className="bg-secondary/60 py-16">
          <div className="mx-auto grid w-full max-w-6xl items-center gap-8 px-4 sm:px-6 md:grid-cols-[auto_1fr]">
            <span className="surface-primary flex size-14 items-center justify-center rounded-2xl">
              <ShieldCheck className="size-7 text-primary-foreground" />
            </span>
            <div>
              <h2 className="text-3xl font-semibold">Privacidade das suas informações</h2>
              <p className="mt-3 max-w-3xl text-muted-foreground">
                Nada do que você compartilha fica visível publicamente. Os profissionais só recebem
                informações não identificáveis sobre o que você procura. Seu nome e contato são
                compartilhados apenas com o profissional selecionado, depois da sua autorização
                expressa.
              </p>
            </div>
          </div>
        </section>

        <section id="faq" className="py-16">
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6">
            <h2 className="text-3xl font-semibold">Perguntas frequentes</h2>
            <Accordion type="single" collapsible className="mt-8">
              <AccordionItem value="1">
                <AccordionTrigger>Preciso criar uma conta?</AccordionTrigger>
                <AccordionContent>
                  Não. Você responde algumas perguntas rápidas e nós cuidamos do resto.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="2">
                <AccordionTrigger>Eu escolho o profissional?</AccordionTrigger>
                <AccordionContent>
                  Nós encontramos profissionais compatíveis com o que você informou e direcionamos a
                  conexão para quem melhor combina com suas necessidades, preferências e
                  disponibilidade.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="3">
                <AccordionTrigger>Quanto custa para mim?</AccordionTrigger>
                <AccordionContent>
                  Nada. Você informa a faixa de investimento por sessão com a qual se sente
                  confortável e conectamos você a profissionais dentro dela.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="4">
                <AccordionTrigger>Quem vê minhas informações?</AccordionTrigger>
                <AccordionContent>
                  Apenas o profissional selecionado, e somente depois da sua autorização. Antes
                  disso, nenhum dado pessoal é exibido.
                </AccordionContent>
              </AccordionItem>
            </Accordion>

            <div className="mt-12 card-soft flex flex-col items-center gap-4 p-10 text-center">
              <h3 className="text-2xl font-semibold">Vamos começar?</h3>
              <p className="max-w-md text-sm text-muted-foreground">
                São poucos minutos para entendermos o que você procura.
              </p>
              <Button asChild size="lg" className="rounded-xl">
                <Link to="/qualificacao">Encontrar um profissional</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border/60 py-8">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-3 px-4 text-sm text-muted-foreground sm:flex-row sm:px-6">
          <span>Conexão Psi — cuidado, compatibilidade e privacidade.</span>
          <Link to="/auth" className="transition-colors hover:text-foreground">
            Área do psicólogo
          </Link>
        </div>
      </footer>
    </div>
  );
}
