import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { SiteHeader } from "@/components/layout/SiteHeader";
import { submitQualification } from "@/lib/qualification.functions";
import {
  AVAILABILITY_OPTIONS,
  FREQUENCIES,
  MODALITIES,
  NEEDS,
  PRICE_RANGES,
  PROFESSIONAL_PREFERENCES,
  START_INTENTS,
} from "@/features/shared/domain";
import { CheckCircle2, HeartHandshake, Loader2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/qualificacao")({
  head: () => ({
    meta: [
      { title: "Vamos encontrar seu profissional — Conexão Psi" },
      {
        name: "description",
        content:
          "Algumas perguntas rápidas e acolhedoras para encontrarmos profissionais compatíveis com o que você procura.",
      },
      { property: "og:title", content: "Vamos encontrar seu profissional — Conexão Psi" },
      {
        property: "og:description",
        content: "Uma conversa breve para entender suas necessidades, preferências e disponibilidade.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: QualificationPage,
});

type Answers = {
  firstName: string;
  whatsapp: string;
  need: string;
  needDetails: string;
  professionalPreference: string;
  modality: string;
  city: string;
  state: string;
  availability: string[];
  startIntent: string;
  priceRange: string;
  frequency: string;
};

const initial: Answers = {
  firstName: "",
  whatsapp: "",
  need: "",
  needDetails: "",
  professionalPreference: "",
  modality: "",
  city: "",
  state: "",
  availability: [],
  startIntent: "",
  priceRange: "",
  frequency: "",
};

type StepId = keyof Answers | "location" | "consent";

function QualificationPage() {
  const submit = useServerFn(submitQualification);
  const [answers, setAnswers] = useState<Answers>(initial);
  const [messages, setMessages] = useState<{ from: "bot" | "user"; text: string }[]>([
    {
      from: "bot",
      text: "Olá! 💙 Vamos ajudar você a encontrar um profissional que combine com o que você está procurando.",
    },
    { from: "bot", text: "Posso fazer algumas perguntas rápidas?" },
    { from: "bot", text: "Para começar, como você gostaria de ser chamado(a)?" },
  ]);
  const [step, setStep] = useState<StepId>("firstName");
  const [consent, setConsent] = useState({ storage: false, matching: false, sharing: false });
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, step]);

  const tracking = useMemo(() => {
    if (typeof window === "undefined") return {};
    const params = new URLSearchParams(window.location.search);
    return {
      utm_source: params.get("utm_source"),
      utm_medium: params.get("utm_medium"),
      utm_campaign: params.get("utm_campaign"),
      utm_content: params.get("utm_content"),
      utm_term: params.get("utm_term"),
      landing_page: window.location.pathname,
      click_id: params.get("gclid") ?? params.get("fbclid"),
    };
  }, []);

  function say(userText: string, nextBotTexts: string[], nextStep: StepId) {
    setMessages((prev) => [
      ...prev,
      { from: "user", text: userText },
      ...nextBotTexts.map((text) => ({ from: "bot" as const, text })),
    ]);
    setStep(nextStep);
  }

  async function finish(finalAnswers: Answers) {
    setLoading(true);
    try {
      await submit({
        data: {
          firstName: finalAnswers.firstName,
          whatsapp: finalAnswers.whatsapp,
          need: finalAnswers.need,
          needDetails: finalAnswers.needDetails || null,
          professionalPreference: finalAnswers.professionalPreference,
          modality: finalAnswers.modality,
          city: finalAnswers.city || null,
          state: finalAnswers.state || null,
          availability: finalAnswers.availability,
          startIntent: finalAnswers.startIntent,
          priceRange: finalAnswers.priceRange,
          frequency: finalAnswers.frequency,
          consent: { storage: true, matching: true, sharing: true },
          tracking,
        },
      });
      setDone(true);
    } catch {
      toast.error("Não conseguimos registrar suas informações agora. Tente novamente em instantes.");
    } finally {
      setLoading(false);
    }
  }

  if (done) {
    return (
      <div className="min-h-screen surface-calm">
        <SiteHeader />
        <main className="mx-auto w-full max-w-2xl px-4 py-16 sm:px-6">
          <div className="card-soft p-8">
            <CheckCircle2 className="size-10 text-primary" />
            <h1 className="mt-5 text-2xl font-semibold">Perfil de Conexão criado 💙</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Status: pronto para encontrar profissionais compatíveis.
            </p>
            <dl className="mt-6 grid gap-4 sm:grid-cols-2">
              <Field label="Atendimento" value={answers.modality} />
              <Field
                label="Localização"
                value={[answers.city, answers.state].filter(Boolean).join(" / ") || "Online"}
              />
              <Field label="Necessidade informada" value={answers.need} />
              <Field label="Preferência" value={answers.professionalPreference} />
              <Field label="Disponibilidade" value={answers.availability.join(", ")} />
              <Field label="Pretende começar" value={answers.startIntent} />
              <Field label="Faixa de investimento" value={answers.priceRange} />
              <Field label="Frequência" value={answers.frequency} />
            </dl>
            <p className="mt-6 rounded-xl bg-secondary p-4 text-sm text-secondary-foreground">
              Estamos verificando disponibilidade e características dos profissionais para apresentar
              as melhores opções para você. Em breve entramos em contato pelo WhatsApp informado.
            </p>
            <Button asChild className="mt-6 rounded-xl">
              <Link to="/">Voltar ao início</Link>
            </Button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen surface-calm">
      <SiteHeader />
      <main className="mx-auto w-full max-w-2xl px-4 py-10 sm:px-6">
        <div className="card-soft flex min-h-[70vh] flex-col overflow-hidden">
          <div className="flex items-center gap-3 border-b border-border/60 p-5">
            <span className="surface-primary flex size-9 items-center justify-center rounded-xl">
              <HeartHandshake className="size-4 text-primary-foreground" />
            </span>
            <div>
              <p className="text-sm font-semibold">Pré-qualificação</p>
              <p className="text-xs text-muted-foreground">
                Suas respostas são privadas e usadas apenas para encontrar profissionais compatíveis.
              </p>
            </div>
          </div>

          <div className="flex-1 space-y-3 overflow-y-auto p-5">
            {messages.map((message, index) => (
              <div
                key={index}
                className={
                  message.from === "bot"
                    ? "max-w-[85%] rounded-2xl rounded-tl-sm bg-secondary px-4 py-3 text-sm text-secondary-foreground"
                    : "ml-auto max-w-[85%] rounded-2xl rounded-tr-sm bg-primary px-4 py-3 text-sm text-primary-foreground"
                }
              >
                {message.text}
              </div>
            ))}
            <div ref={bottomRef} />
          </div>

          <div className="border-t border-border/60 bg-card p-5">
            {step === "firstName" && (
              <TextStep
                placeholder="Seu primeiro nome"
                onSubmit={(value) => {
                  setAnswers((a) => ({ ...a, firstName: value }));
                  say(value, [
                    `Prazer, ${value}! Qual o seu WhatsApp com DDD? É por ele que o profissional vai falar com você.`,
                  ], "whatsapp");
                }}
              />
            )}

            {step === "whatsapp" && (
              <TextStep
                placeholder="(11) 90000-0000"
                validate={(v) => v.replace(/\D/g, "").length >= 10}
                errorMessage="Informe um telefone com DDD."
                onSubmit={(value) => {
                  setAnswers((a) => ({ ...a, whatsapp: value }));
                  say(value, ["O que você está buscando neste momento?"], "need");
                }}
              />
            )}

            {step === "need" && (
              <OptionsStep
                options={[...NEEDS]}
                onSelect={(value) => {
                  setAnswers((a) => ({ ...a, need: value }));
                  say(value, [
                    "Se quiser, conte um pouco mais sobre o que está acontecendo. É opcional.",
                  ], "needDetails");
                }}
              />
            )}

            {step === "needDetails" && (
              <TextAreaStep
                onSubmit={(value) => {
                  setAnswers((a) => ({ ...a, needDetails: value }));
                  say(value || "Prefiro não detalhar agora", [
                    "Você tem preferência sobre o profissional?",
                  ], "professionalPreference");
                }}
              />
            )}

            {step === "professionalPreference" && (
              <OptionsStep
                options={[...PROFESSIONAL_PREFERENCES]}
                onSelect={(value) => {
                  setAnswers((a) => ({ ...a, professionalPreference: value }));
                  say(value, ["Como você prefere ser atendido(a)?"], "modality");
                }}
              />
            )}

            {step === "modality" && (
              <OptionsStep
                options={[...MODALITIES]}
                onSelect={(value) => {
                  setAnswers((a) => ({ ...a, modality: value }));
                  if (value === "presencial") {
                    say(value, ["Em qual cidade e estado você gostaria de ser atendido(a)?"], "location");
                  } else {
                    say(value, ["Quais horários funcionam melhor para você?"], "availability");
                  }
                }}
              />
            )}

            {step === "location" && (
              <LocationStep
                onSubmit={(city, state) => {
                  setAnswers((a) => ({ ...a, city, state }));
                  say(`${city} / ${state}`, ["Quais horários funcionam melhor para você?"], "availability");
                }}
              />
            )}

            {step === "availability" && (
              <MultiStep
                options={[...AVAILABILITY_OPTIONS]}
                onSubmit={(values) => {
                  setAnswers((a) => ({ ...a, availability: values }));
                  say(values.join(", "), ["Quando você pretende começar?"], "startIntent");
                }}
              />
            )}

            {step === "startIntent" && (
              <OptionsStep
                options={[...START_INTENTS]}
                onSelect={(value) => {
                  setAnswers((a) => ({ ...a, startIntent: value }));
                  say(value, [
                    "Com qual faixa de investimento por sessão você se sente confortável?",
                  ], "priceRange");
                }}
              />
            )}

            {step === "priceRange" && (
              <OptionsStep
                options={[...PRICE_RANGES]}
                onSelect={(value) => {
                  setAnswers((a) => ({ ...a, priceRange: value }));
                  say(value, ["Com que frequência você pretende fazer as sessões?"], "frequency");
                }}
              />
            )}

            {step === "frequency" && (
              <OptionsStep
                options={[...FREQUENCIES]}
                onSelect={(value) => {
                  setAnswers((a) => ({ ...a, frequency: value }));
                  say(value, [
                    "Antes de finalizar, precisamos da sua autorização para cuidar das suas informações.",
                  ], "consent");
                }}
              />
            )}

            {step === "consent" && (
              <div className="space-y-4">
                <ConsentCheck
                  checked={consent.storage}
                  onChange={(v) => setConsent((c) => ({ ...c, storage: v }))}
                  label="Autorizo o armazenamento das informações que forneci."
                />
                <ConsentCheck
                  checked={consent.matching}
                  onChange={(v) => setConsent((c) => ({ ...c, matching: v }))}
                  label="Autorizo o uso dessas informações para encontrar profissionais compatíveis."
                />
                <ConsentCheck
                  checked={consent.sharing}
                  onChange={(v) => setConsent((c) => ({ ...c, sharing: v }))}
                  label="Autorizo o compartilhamento das informações autorizadas com o profissional selecionado."
                />
                <Button
                  className="w-full rounded-xl"
                  disabled={!consent.storage || !consent.matching || !consent.sharing || loading}
                  onClick={() => finish(answers)}
                >
                  {loading ? <Loader2 className="size-4 animate-spin" /> : "Concluir e encontrar profissionais"}
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border p-4">
      <dt className="text-xs uppercase tracking-wide text-muted-foreground">{label}</dt>
      <dd className="mt-1 text-sm font-medium capitalize">{value || "—"}</dd>
    </div>
  );
}

function TextStep({
  placeholder,
  onSubmit,
  validate,
  errorMessage,
}: {
  placeholder: string;
  onSubmit: (value: string) => void;
  validate?: (value: string) => boolean;
  errorMessage?: string;
}) {
  const [value, setValue] = useState("");
  const [error, setError] = useState("");
  return (
    <form
      className="flex gap-2"
      onSubmit={(event) => {
        event.preventDefault();
        const trimmed = value.trim();
        if (trimmed.length < 2 || (validate && !validate(trimmed))) {
          setError(errorMessage ?? "Informe uma resposta válida.");
          return;
        }
        setError("");
        onSubmit(trimmed);
        setValue("");
      }}
    >
      <div className="flex-1">
        <Input
          value={value}
          maxLength={60}
          placeholder={placeholder}
          onChange={(e) => setValue(e.target.value)}
          className="rounded-xl"
        />
        {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
      </div>
      <Button type="submit" className="rounded-xl">
        Enviar
      </Button>
    </form>
  );
}

function TextAreaStep({ onSubmit }: { onSubmit: (value: string) => void }) {
  const [value, setValue] = useState("");
  return (
    <div className="space-y-3">
      <Textarea
        value={value}
        maxLength={600}
        rows={3}
        placeholder="Opcional"
        onChange={(e) => setValue(e.target.value)}
        className="rounded-xl"
      />
      <div className="flex gap-2">
        <Button className="rounded-xl" onClick={() => onSubmit(value.trim())}>
          Continuar
        </Button>
        <Button variant="ghost" className="rounded-xl" onClick={() => onSubmit("")}>
          Pular
        </Button>
      </div>
    </div>
  );
}

function OptionsStep({
  options,
  onSelect,
}: {
  options: string[];
  onSelect: (value: string) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((option) => (
        <Button
          key={option}
          variant="outline"
          className="rounded-xl capitalize"
          onClick={() => onSelect(option)}
        >
          {option}
        </Button>
      ))}
    </div>
  );
}

function MultiStep({
  options,
  onSubmit,
}: {
  options: string[];
  onSubmit: (values: string[]) => void;
}) {
  const [selected, setSelected] = useState<string[]>([]);
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        {options.map((option) => {
          const active = selected.includes(option);
          return (
            <Button
              key={option}
              variant={active ? "default" : "outline"}
              className="rounded-xl capitalize"
              onClick={() =>
                setSelected((prev) =>
                  prev.includes(option) ? prev.filter((p) => p !== option) : [...prev, option],
                )
              }
            >
              {option}
            </Button>
          );
        })}
      </div>
      <Button
        className="rounded-xl"
        disabled={selected.length === 0}
        onClick={() => onSubmit(selected)}
      >
        Continuar
      </Button>
    </div>
  );
}

function LocationStep({ onSubmit }: { onSubmit: (city: string, state: string) => void }) {
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  return (
    <div className="flex flex-col gap-2 sm:flex-row">
      <Input
        value={city}
        maxLength={80}
        placeholder="Cidade"
        onChange={(e) => setCity(e.target.value)}
        className="rounded-xl"
      />
      <Input
        value={state}
        maxLength={2}
        placeholder="UF"
        onChange={(e) => setState(e.target.value.toUpperCase())}
        className="rounded-xl sm:w-24"
      />
      <Button
        className="rounded-xl"
        disabled={city.trim().length < 2 || state.trim().length < 2}
        onClick={() => onSubmit(city.trim(), state.trim())}
      >
        Continuar
      </Button>
    </div>
  );
}

function ConsentCheck({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
}) {
  return (
    <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-border p-3 text-sm">
      <Checkbox checked={checked} onCheckedChange={(v) => onChange(Boolean(v))} className="mt-0.5" />
      <span className="text-muted-foreground">{label}</span>
    </label>
  );
}
