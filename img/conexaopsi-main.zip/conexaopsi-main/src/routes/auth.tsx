import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SiteHeader } from "@/components/layout/SiteHeader";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Área do psicólogo — Conexão Psi" },
      {
        name: "description",
        content:
          "Acesse sua conta para ver oportunidades de conexão compatíveis com o seu perfil profissional.",
      },
      { property: "og:title", content: "Área do psicólogo — Conexão Psi" },
      {
        property: "og:description",
        content: "Entre ou crie sua conta profissional na Conexão Psi.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [emailSent, setEmailSent] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/painel", replace: true });
    });
  }, [navigate]);

  async function signIn() {
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      toast.error("Não foi possível entrar. Verifique seu e-mail e senha.");
      return;
    }
    navigate({ to: "/painel", replace: true });
  }

  async function signUp() {
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: window.location.origin,
        data: { full_name: fullName },
      },
    });
    setLoading(false);
    if (error) {
      toast.error("Não foi possível criar a conta. Tente novamente.");
      return;
    }
    if (data.session) {
      navigate({ to: "/painel", replace: true });
      return;
    }
    setEmailSent(true);
  }

  return (
    <div className="min-h-screen surface-calm">
      <SiteHeader />
      <main className="mx-auto w-full max-w-md px-4 py-16 sm:px-6">
        <div className="card-soft p-8">
          <h1 className="text-2xl font-semibold">Área do psicólogo</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Receba oportunidades de conexão compatíveis com o seu perfil profissional.
          </p>

          {emailSent ? (
            <p className="mt-6 rounded-xl bg-secondary p-4 text-sm text-secondary-foreground">
              Enviamos um e-mail de confirmação para {email}. Confirme seu endereço para acessar sua
              conta.
            </p>
          ) : (
            <Tabs defaultValue="entrar" className="mt-6">
              <TabsList className="w-full">
                <TabsTrigger value="entrar" className="flex-1">
                  Entrar
                </TabsTrigger>
                <TabsTrigger value="criar" className="flex-1">
                  Criar conta
                </TabsTrigger>
              </TabsList>

              <TabsContent value="entrar" className="mt-6 space-y-4">
                <EmailPassword
                  email={email}
                  password={password}
                  setEmail={setEmail}
                  setPassword={setPassword}
                />
                <Button className="w-full rounded-xl" disabled={loading} onClick={signIn}>
                  {loading ? <Loader2 className="size-4 animate-spin" /> : "Entrar"}
                </Button>
              </TabsContent>

              <TabsContent value="criar" className="mt-6 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome completo</Label>
                  <Input
                    id="nome"
                    value={fullName}
                    maxLength={120}
                    onChange={(e) => setFullName(e.target.value)}
                    className="rounded-xl"
                  />
                </div>
                <EmailPassword
                  email={email}
                  password={password}
                  setEmail={setEmail}
                  setPassword={setPassword}
                />
                <Button
                  className="w-full rounded-xl"
                  disabled={loading || fullName.trim().length < 3}
                  onClick={signUp}
                >
                  {loading ? <Loader2 className="size-4 animate-spin" /> : "Criar conta"}
                </Button>
              </TabsContent>
            </Tabs>
          )}

        </div>
      </main>
    </div>
  );
}

function EmailPassword({
  email,
  password,
  setEmail,
  setPassword,
}: {
  email: string;
  password: string;
  setEmail: (value: string) => void;
  setPassword: (value: string) => void;
}) {
  return (
    <>
      <div className="space-y-2">
        <Label htmlFor="email">E-mail</Label>
        <Input
          id="email"
          type="email"
          value={email}
          maxLength={255}
          onChange={(e) => setEmail(e.target.value)}
          className="rounded-xl"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="senha">Senha</Label>
        <Input
          id="senha"
          type="password"
          value={password}
          maxLength={72}
          onChange={(e) => setPassword(e.target.value)}
          className="rounded-xl"
        />
      </div>
    </>
  );
}
