import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const idSchema = z.object({ opportunityId: z.string().uuid() });

export const fetchDashboard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { getDashboard } = await import("./opportunities.server");
    return getDashboard(context.userId);
  });

export const fetchOpportunities = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { listOpportunitiesFor } = await import("./opportunities.server");
    return listOpportunitiesFor(context.userId);
  });

export const manifestInterestFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { opportunityId: string; amount: number }) =>
    z.object({ opportunityId: z.string().uuid(), amount: z.number().min(10).max(5000) }).parse(data),
  )
  .handler(async ({ data, context }) => {
    const { manifestInterest } = await import("./opportunities.server");
    return manifestInterest(context.userId, data.opportunityId, data.amount);
  });

export const closeOpportunityFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { opportunityId: string }) => idSchema.parse(data))
  .handler(async ({ data }) => {
    const { closeAndSelect } = await import("./opportunities.server");
    return { status: await closeAndSelect(data.opportunityId) };
  });

export const confirmConnectionFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { opportunityId: string }) => idSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { confirmConnection } = await import("./opportunities.server");
    return confirmConnection(context.userId, data.opportunityId);
  });

export const fetchConnections = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { listConnections } = await import("./opportunities.server");
    return listConnections(context.userId);
  });

export const fetchConnectionTimeline = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { connectionId: string }) =>
    z.object({ connectionId: z.string().uuid() }).parse(data),
  )
  .handler(async ({ data, context }) => {
    const { listConnectionTimeline } = await import("./opportunities.server");
    return listConnectionTimeline(context.userId, data.connectionId);
  });

export const updateConnectionStageFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { connectionId: string; stage: string; note?: string }) =>
    z
      .object({
        connectionId: z.string().uuid(),
        stage: z.string().max(40),
        note: z.string().max(400).optional(),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    const { updateConnectionStage } = await import("./opportunities.server");
    return updateConnectionStage(context.userId, data.connectionId, data.stage, data.note);
  });

export const fetchWallet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { getWallet } = await import("./opportunities.server");
    return getWallet(context.userId);
  });

export const addCreditsFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { amount: number }) =>
    z.object({ amount: z.number().min(50).max(5000) }).parse(data),
  )
  .handler(async ({ data, context }) => {
    const { addDemoCredits } = await import("./opportunities.server");
    return addDemoCredits(context.userId, data.amount);
  });

export const fetchProfessionalProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { getProfessional, getPreferences, profileCompleteness } = await import(
      "./opportunities.server"
    );
    const profile = await getProfessional(context.userId);
    const preferences = await getPreferences(context.userId);
    return {
      profile,
      preferences,
      completeness: profileCompleteness(profile as Record<string, unknown> | null),
    };
  });

const profileSchema = z.object({
  display_name: z.string().trim().min(2).max(120),
  crp: z.string().trim().max(30).nullable().optional(),
  crp_state: z.string().trim().max(4).nullable().optional(),
  bio: z.string().trim().max(1200).nullable().optional(),
  education: z.string().trim().max(300).nullable().optional(),
  years_experience: z.number().int().min(0).max(70).nullable().optional(),
  specialties: z.array(z.string().max(60)).max(15),
  audiences: z.array(z.string().max(40)).max(10),
  approaches: z.array(z.string().max(40)).max(10),
  modalities: z.array(z.string().max(20)).max(3),
  city: z.string().trim().max(80).nullable().optional(),
  state: z.string().trim().max(4).nullable().optional(),
  online_care: z.boolean(),
  min_price: z.number().min(0).max(5000).nullable().optional(),
  max_price: z.number().min(0).max(5000).nullable().optional(),
  availability: z.array(z.string().max(30)).max(8),
  gender: z.string().max(20).nullable().optional(),
});

export const saveProfessionalProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: z.infer<typeof profileSchema>) => profileSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { upsertProfessionalProfile } = await import("./opportunities.server");
    return upsertProfessionalProfile(context.userId, data);
  });

const preferencesSchema = z.object({
  needs: z.array(z.string().max(60)).max(15),
  specialties: z.array(z.string().max(60)).max(15),
  cities: z.array(z.string().max(80)).max(20),
  states: z.array(z.string().max(4)).max(27),
  online_only: z.boolean(),
  in_person: z.boolean(),
  price_ranges: z.array(z.string().max(30)).max(6),
  schedules: z.array(z.string().max(30)).max(8),
  audiences: z.array(z.string().max(40)).max(10),
  receive_opportunities: z.boolean(),
});

export const savePreferences = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: z.infer<typeof preferencesSchema>) => preferencesSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { upsertPreferences } = await import("./opportunities.server");
    return upsertPreferences(context.userId, data);
  });
