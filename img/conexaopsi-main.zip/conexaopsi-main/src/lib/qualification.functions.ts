import { createServerFn } from "@tanstack/react-start";
import { qualificationSchema, type QualificationInput } from "./qualification.schema";

export const submitQualification = createServerFn({ method: "POST" })
  .inputValidator((data: QualificationInput) => qualificationSchema.parse(data))
  .handler(async ({ data }) => {
    const { createQualifiedLead } = await import("./qualification.server");
    return createQualifiedLead(data);
  });
