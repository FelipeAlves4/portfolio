import {
  checkEligibility,
  compatibilityScore,
  finalScore,
  normalizePriority,
  type OpportunitySignals,
  type ProfessionalSignals,
} from "@/features/matching/scoring";
import { estimateFollowUp } from "@/features/shared/domain";
import { loadSettings, recordAudit, recordConversion, recordLeadEvent, supabaseAdmin } from "./platform.server";

type OppContext = {
  need: string;
  modality: string;
  city: string | null;
  state: string | null;
  availability: string[] | null;
  price_range: string | null;
  frequency: string | null;
  start_intent: string | null;
};

export async function getProfessional(userId: string) {
  const { data } = await supabaseAdmin
    .from("psychologist_profiles")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();
  return data;
}

function toProSignals(pro: NonNullable<Awaited<ReturnType<typeof getProfessional>>>): ProfessionalSignals {
  return {
    specialties: pro.specialties ?? [],
    modalities: pro.modalities ?? [],
    online_care: pro.online_care,
    city: pro.city,
    state: pro.state,
    gender: pro.gender,
    availability: pro.availability ?? [],
    min_price: pro.min_price ? Number(pro.min_price) : null,
    max_price: pro.max_price ? Number(pro.max_price) : null,
    quality_score: pro.quality_score,
  };
}

function toOppSignals(opp: {
  need: string;
  modality: string;
  city: string | null;
  state: string | null;
  professional_preference: string | null;
  availability: string[];
  price_range: string | null;
}): OpportunitySignals {
  return {
    need: opp.need,
    modality: opp.modality,
    city: opp.city,
    state: opp.state,
    professional_preference: opp.professional_preference,
    availability: opp.availability ?? [],
    price_range: opp.price_range,
  };
}

export async function listOpportunitiesFor(userId: string) {
  await expireStaleOpportunities();
  const settings = await loadSettings();
  const pro = await getProfessional(userId);

  const { data: opportunities } = await supabaseAdmin
    .from("connection_opportunities")
    .select("*")
    .in("status", ["OPEN", "SELECTING", "PROFESSIONAL_SELECTED", "PAYMENT_PENDING"])
    .order("created_at", { ascending: false })
    .limit(30);

  const { data: mine } = await supabaseAdmin
    .from("interest_manifestations")
    .select("opportunity_id, priority_amount")
    .eq("user_id", userId);
  const manifested = new Map((mine ?? []).map((m) => [m.opportunity_id, Number(m.priority_amount)]));

  return (opportunities ?? []).map((opp) => {
    const eligibility = pro
      ? checkEligibility(toOppSignals(opp), toProSignals(pro))
      : { eligible: false, reason: "Complete seu perfil profissional" };
    const score =
      pro && eligibility.eligible
        ? compatibilityScore(toOppSignals(opp), toProSignals(pro), settings.matching)
        : 0;

    return {
      id: opp.id,
      status: opp.status,
      need: opp.need,
      needDetails: opp.need_details,
      modality: opp.modality,
      city: opp.city,
      state: opp.state,
      professionalPreference: opp.professional_preference,
      availability: opp.availability ?? [],
      startIntent: opp.start_intent,
      priceRange: opp.price_range,
      frequency: opp.frequency,
      basePrice: Number(opp.base_price),
      closesAt: opp.closes_at,
      selectedForMe: opp.selected_user_id === userId,
      selectedAmount: opp.selected_amount ? Number(opp.selected_amount) : null,
      paymentDueAt: opp.payment_due_at,
      compatibility: score,
      eligible: eligibility.eligible,
      ineligibleReason: eligibility.reason ?? null,
      myPriority: manifested.get(opp.id) ?? null,
      estimate: estimateFollowUp(opp.price_range, opp.frequency),
      isDemo: opp.is_demo,
    };
  });
}

export async function manifestInterest(userId: string, opportunityId: string, amount: number) {
  const settings = await loadSettings();
  const pro = await getProfessional(userId);
  if (!pro) throw new Error("Complete seu perfil profissional antes de manifestar interesse.");

  const { data: opp } = await supabaseAdmin
    .from("connection_opportunities")
    .select("*")
    .eq("id", opportunityId)
    .maybeSingle();
  if (!opp) throw new Error("Oportunidade não encontrada.");
  if (opp.status !== "OPEN" || new Date(opp.closes_at).getTime() < Date.now()) {
    throw new Error("A janela de conexão desta oportunidade já foi encerrada.");
  }

  const eligibility = checkEligibility(toOppSignals(opp), toProSignals(pro));
  if (!eligibility.eligible) throw new Error(eligibility.reason ?? "Perfil não elegível.");

  const { data: wallet } = await supabaseAdmin
    .from("wallets")
    .select("balance")
    .eq("user_id", userId)
    .maybeSingle();
  if (!wallet || Number(wallet.balance) < amount) {
    throw new Error("Saldo de créditos insuficiente para esta prioridade de conexão.");
  }

  const compatibility = compatibilityScore(toOppSignals(opp), toProSignals(pro), settings.matching);

  const { error } = await supabaseAdmin.from("interest_manifestations").upsert(
    {
      opportunity_id: opportunityId,
      user_id: userId,
      priority_amount: amount,
      compatibility_score: compatibility,
      final_score: compatibility,
    },
    { onConflict: "opportunity_id,user_id" },
  );
  if (error) throw new Error("Não foi possível registrar sua manifestação de interesse.");

  await recordConversion("INTEREST_RECEIVED", "opportunity", opportunityId, "app", { userId });
  await recordAudit(userId, "interest.manifested", "opportunity", opportunityId, { amount });

  return { compatibility };
}

/** Encerra a janela e direciona a conexão ao profissional mais adequado. */
export async function closeAndSelect(opportunityId: string) {
  const settings = await loadSettings();
  const { data: opp } = await supabaseAdmin
    .from("connection_opportunities")
    .select("*")
    .eq("id", opportunityId)
    .maybeSingle();
  if (!opp) return null;
  if (opp.status !== "OPEN") return opp.status;
  if (new Date(opp.closes_at).getTime() > Date.now()) return opp.status;

  await supabaseAdmin.from("connection_opportunities").update({ status: "SELECTING" }).eq("id", opportunityId);

  const { data: candidates } = await supabaseAdmin
    .from("interest_manifestations")
    .select("*")
    .eq("opportunity_id", opportunityId);

  if (!candidates || candidates.length === 0) {
    await supabaseAdmin
      .from("connection_opportunities")
      .update({ status: "NO_CANDIDATES" })
      .eq("id", opportunityId);
    return "NO_CANDIDATES";
  }

  const maxAmount = Math.max(...candidates.map((c) => Number(c.priority_amount)));
  const ranked = candidates
    .map((c) => ({
      ...c,
      score: finalScore(
        c.compatibility_score,
        normalizePriority(Number(c.priority_amount), maxAmount),
        settings.finalScore,
      ),
    }))
    .sort((a, b) => b.score - a.score);

  for (const candidate of ranked) {
    await supabaseAdmin
      .from("interest_manifestations")
      .update({ final_score: candidate.score })
      .eq("id", candidate.id);
  }

  const winner = ranked[0]!;
  await supabaseAdmin
    .from("connection_opportunities")
    .update({
      status: "PROFESSIONAL_SELECTED",
      selected_user_id: winner.user_id,
      selected_amount: winner.priority_amount,
      payment_due_at: new Date(Date.now() + settings.paymentWindowSeconds * 1000).toISOString(),
    })
    .eq("id", opportunityId);

  await recordConversion("PROFESSIONAL_SELECTED", "opportunity", opportunityId, "matching", {
    finalScore: winner.score,
  });

  return "PROFESSIONAL_SELECTED";
}

export async function expireStaleOpportunities() {
  const { data: open } = await supabaseAdmin
    .from("connection_opportunities")
    .select("id")
    .eq("status", "OPEN")
    .lt("closes_at", new Date().toISOString());
  for (const opp of open ?? []) {
    await closeAndSelect(opp.id);
  }
}

/** Confirmação da conexão: debita créditos, registra pagamento e libera contato. */
export async function confirmConnection(userId: string, opportunityId: string) {
  const { data: opp } = await supabaseAdmin
    .from("connection_opportunities")
    .select("*, connection_profiles(lead_id)")
    .eq("id", opportunityId)
    .maybeSingle();
  if (!opp || opp.selected_user_id !== userId) {
    throw new Error("Esta conexão não está direcionada ao seu perfil.");
  }
  if (!["PROFESSIONAL_SELECTED", "PAYMENT_PENDING"].includes(opp.status)) {
    throw new Error("Esta conexão não está disponível para confirmação.");
  }
  if (opp.payment_due_at && new Date(opp.payment_due_at).getTime() < Date.now()) {
    await supabaseAdmin
      .from("connection_opportunities")
      .update({ status: "PAYMENT_EXPIRED" })
      .eq("id", opportunityId);
    throw new Error("O prazo para confirmação desta conexão foi encerrado.");
  }

  const amount = Number(opp.selected_amount ?? opp.base_price);
  const { data: wallet } = await supabaseAdmin
    .from("wallets")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();
  if (!wallet || Number(wallet.balance) < amount) {
    throw new Error("Saldo insuficiente. Adicione créditos para confirmar esta conexão.");
  }

  const leadId = (opp.connection_profiles as { lead_id: string } | null)?.lead_id;
  if (!leadId) throw new Error("Perfil de conexão indisponível.");

  const { data: lead } = await supabaseAdmin
    .from("leads")
    .select("attributed_cost")
    .eq("id", leadId)
    .maybeSingle();

  const { data: manifestation } = await supabaseAdmin
    .from("interest_manifestations")
    .select("compatibility_score")
    .eq("opportunity_id", opportunityId)
    .eq("user_id", userId)
    .maybeSingle();

  await supabaseAdmin.from("payments").insert({
    user_id: userId,
    amount,
    status: "PAID",
    provider: "demo",
    provider_reference: `demo-${opportunityId.slice(0, 8)}`,
  });

  await supabaseAdmin
    .from("wallets")
    .update({ balance: Number(wallet.balance) - amount })
    .eq("user_id", userId);

  await supabaseAdmin.from("credit_transactions").insert({
    user_id: userId,
    amount: -amount,
    kind: "CONNECTION",
    description: "Conexão realizada",
  });

  const { data: connection, error } = await supabaseAdmin
    .from("connections")
    .insert({
      opportunity_id: opportunityId,
      lead_id: leadId,
      user_id: userId,
      amount,
      compatibility_score: manifestation?.compatibility_score ?? 0,
      contact_unlocked: true,
      stage: "CONTACT_PENDING",
      attributed_cost: Number(lead?.attributed_cost ?? 0),
    })
    .select("id")
    .single();
  if (error || !connection) throw new Error("Não foi possível concluir a conexão.");

  await supabaseAdmin.from("connection_events").insert({
    connection_id: connection.id,
    stage: "CONNECTION_MADE",
    note: "Conexão confirmada e contato liberado",
  });

  await supabaseAdmin
    .from("connection_opportunities")
    .update({ status: "CONTACT_UNLOCKED" })
    .eq("id", opportunityId);
  await supabaseAdmin.from("leads").update({ status: "CONNECTED" }).eq("id", leadId);
  await recordLeadEvent(leadId, "OPPORTUNITY_CREATED", "CONNECTED", "Conexão realizada");
  await recordConversion("PAYMENT_COMPLETED", "connection", connection.id, "app", { amount });
  await recordConversion("CONTACT_UNLOCKED", "connection", connection.id, "app");
  await recordAudit(userId, "connection.confirmed", "connection", connection.id, { amount });

  return { connectionId: connection.id };
}

/** Dados identificáveis só são retornados quando a conexão está autorizada. */
export async function listConnections(userId: string) {
  const { data } = await supabaseAdmin
    .from("connections")
    .select("*, leads(first_name, whatsapp), connection_opportunities(need, modality, city, state, availability, price_range, frequency, start_intent)")
    .eq("user_id", userId)
    .order("created_at", { ascending: false });

  return (data ?? []).map((c) => {
    const lead = c.leads as { first_name: string; whatsapp: string } | null;
    const opp = c.connection_opportunities as OppContext | null;
    const unlocked = c.contact_unlocked;
    return {
      id: c.id,
      amount: Number(c.amount),
      compatibility: c.compatibility_score,
      stage: c.stage,
      createdAt: c.created_at,
      contactUnlocked: unlocked,
      person: unlocked && lead ? { firstName: lead.first_name, whatsapp: lead.whatsapp } : null,
      context: opp
        ? {
            need: opp.need,
            modality: opp.modality,
            city: opp.city,
            availability: opp.availability ?? [],
            priceRange: opp.price_range,
            frequency: opp.frequency,
            startIntent: opp.start_intent,
          }
        : null,
    };
  });
}

export async function listConnectionTimeline(userId: string, connectionId: string) {
  const { data: connection } = await supabaseAdmin
    .from("connections")
    .select("id")
    .eq("id", connectionId)
    .eq("user_id", userId)
    .maybeSingle();
  if (!connection) throw new Error("Conexão não encontrada.");
  const { data } = await supabaseAdmin
    .from("connection_events")
    .select("*")
    .eq("connection_id", connectionId)
    .order("created_at", { ascending: true });
  return data ?? [];
}

const STAGE_EVENTS: Record<string, string | null> = {
  CONTACTED: "CONTACTED",
  APPOINTMENT_SCHEDULED: "APPOINTMENT_SCHEDULED",
  TREATMENT_STARTED: "TREATMENT_STARTED",
};

export async function updateConnectionStage(userId: string, connectionId: string, stage: string, note?: string) {
  const { data: connection } = await supabaseAdmin
    .from("connections")
    .select("id, lead_id")
    .eq("id", connectionId)
    .eq("user_id", userId)
    .maybeSingle();
  if (!connection) throw new Error("Conexão não encontrada.");

  await supabaseAdmin.from("connections").update({ stage: stage as never }).eq("id", connectionId);
  await supabaseAdmin.from("connection_events").insert({
    connection_id: connectionId,
    stage: stage as never,
    note: note ?? null,
  });

  const conversion = STAGE_EVENTS[stage];
  if (conversion) await recordConversion(conversion, "connection", connectionId, "app");
  if (stage === "TREATMENT_STARTED") {
    await supabaseAdmin.from("leads").update({ status: "CONVERTED" }).eq("id", connection.lead_id);
    await recordLeadEvent(connection.lead_id, "CONNECTED", "CONVERTED", "Atendimento iniciado");
  }
  return { ok: true };
}

export async function getWallet(userId: string) {
  const { data: wallet } = await supabaseAdmin
    .from("wallets")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();
  if (!wallet) {
    await supabaseAdmin.from("wallets").insert({ user_id: userId });
  }
  const { data: transactions } = await supabaseAdmin
    .from("credit_transactions")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(30);
  return {
    balance: Number(wallet?.balance ?? 0),
    transactions: (transactions ?? []).map((t) => ({
      id: t.id,
      amount: Number(t.amount),
      kind: t.kind,
      description: t.description,
      createdAt: t.created_at,
    })),
  };
}

/** MODO DEMONSTRAÇÃO: crédito adicionado sem gateway externo. */
export async function addDemoCredits(userId: string, amount: number) {
  const { data: wallet } = await supabaseAdmin
    .from("wallets")
    .select("balance")
    .eq("user_id", userId)
    .maybeSingle();
  const balance = Number(wallet?.balance ?? 0) + amount;
  if (wallet) {
    await supabaseAdmin.from("wallets").update({ balance }).eq("user_id", userId);
  } else {
    await supabaseAdmin.from("wallets").insert({ user_id: userId, balance });
  }
  await supabaseAdmin.from("credit_transactions").insert({
    user_id: userId,
    amount,
    kind: "TOPUP",
    description: "Compra de créditos (modo demonstração)",
  });
  await supabaseAdmin.from("payments").insert({
    user_id: userId,
    amount,
    status: "PAID",
    provider: "demo",
  });
  await recordAudit(userId, "credits.added", "wallet", null, { amount, mode: "demo" });
  return { balance };
}

export async function getDashboard(userId: string) {
  const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString();
  const [opportunities, connections, wallet] = await Promise.all([
    listOpportunitiesFor(userId),
    supabaseAdmin.from("connections").select("stage, created_at, amount").eq("user_id", userId),
    getWallet(userId),
  ]);
  const rows = connections.data ?? [];
  const monthRows = rows.filter((r) => r.created_at >= monthStart);
  return {
    newOpportunities: opportunities.filter((o) => o.eligible && o.status === "OPEN" && !o.myPriority).length,
    connectionsThisMonth: monthRows.length,
    contacted: rows.filter((r) =>
      ["CONTACTED", "APPOINTMENT_SCHEDULED", "TREATMENT_STARTED"].includes(r.stage),
    ).length,
    scheduled: rows.filter((r) => ["APPOINTMENT_SCHEDULED", "TREATMENT_STARTED"].includes(r.stage)).length,
    started: rows.filter((r) => r.stage === "TREATMENT_STARTED").length,
    balance: wallet.balance,
    monthlySeries: buildMonthlySeries(rows),
  };
}

function buildMonthlySeries(rows: { created_at: string; stage: string }[]) {
  const months: { label: string; conexoes: number; atendimentos: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const date = new Date();
    date.setMonth(date.getMonth() - i, 1);
    const key = date.toISOString().slice(0, 7);
    const label = date.toLocaleDateString("pt-BR", { month: "short" });
    const inMonth = rows.filter((r) => r.created_at.slice(0, 7) === key);
    months.push({
      label,
      conexoes: inMonth.length,
      atendimentos: inMonth.filter((r) => r.stage === "TREATMENT_STARTED").length,
    });
  }
  return months;
}

export async function upsertProfessionalProfile(userId: string, input: Record<string, unknown>) {
  const { error } = await supabaseAdmin
    .from("psychologist_profiles")
    .upsert({ user_id: userId, ...input } as never, { onConflict: "user_id" });
  if (error) throw new Error("Não foi possível salvar o perfil profissional.");
  await recordAudit(userId, "profile.updated", "psychologist_profile", null, {});
  return { ok: true };
}

export async function getPreferences(userId: string) {
  const { data } = await supabaseAdmin
    .from("psychologist_preferences")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();
  return data;
}

export async function upsertPreferences(userId: string, input: Record<string, unknown>) {
  const { error } = await supabaseAdmin
    .from("psychologist_preferences")
    .upsert({ user_id: userId, ...input } as never, { onConflict: "user_id" });
  if (error) throw new Error("Não foi possível salvar suas preferências.");
  return { ok: true };
}

export function profileCompleteness(profile: Record<string, unknown> | null): number {
  if (!profile) return 0;
  const fields = [
    "display_name",
    "crp",
    "crp_state",
    "bio",
    "education",
    "years_experience",
    "specialties",
    "audiences",
    "approaches",
    "modalities",
    "city",
    "state",
    "min_price",
    "max_price",
    "availability",
    "gender",
  ];
  const filled = fields.filter((f) => {
    const value = profile[f];
    if (Array.isArray(value)) return value.length > 0;
    return value !== null && value !== undefined && value !== "";
  }).length;
  return Math.round((filled / fields.length) * 100);
}
