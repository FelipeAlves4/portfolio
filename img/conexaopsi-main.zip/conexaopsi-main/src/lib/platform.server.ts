import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  DEFAULT_FINAL_SCORE_WEIGHTS,
  DEFAULT_MATCHING_WEIGHTS,
  type FinalScoreWeights,
  type MatchingWeights,
} from "@/features/matching/scoring";

export { supabaseAdmin };

export type PlatformSettings = {
  matching: MatchingWeights;
  finalScore: FinalScoreWeights;
  connectionWindowSeconds: number;
  paymentWindowSeconds: number;
};

export async function loadSettings(): Promise<PlatformSettings> {
  const { data } = await supabaseAdmin.from("platform_settings").select("key, value");
  const map = new Map((data ?? []).map((row) => [row.key, row.value]));
  return {
    matching: (map.get("matching_weights") as MatchingWeights) ?? DEFAULT_MATCHING_WEIGHTS,
    finalScore: (map.get("final_score_weights") as FinalScoreWeights) ?? DEFAULT_FINAL_SCORE_WEIGHTS,
    connectionWindowSeconds: Number(map.get("connection_window_seconds") ?? 300),
    paymentWindowSeconds: Number(map.get("payment_window_seconds") ?? 600),
  };
}

export async function recordConversion(
  eventType: string,
  entity: string,
  entityId: string | null,
  origin: string,
  metadata: Record<string, unknown> = {},
) {
  await supabaseAdmin.from("conversion_events").insert({
    event_type: eventType,
    entity,
    entity_id: entityId,
    origin,
    metadata: metadata as never,
  });
}

export async function recordAudit(
  actorId: string | null,
  action: string,
  entity: string,
  entityId: string | null,
  metadata: Record<string, unknown> = {},
) {
  await supabaseAdmin.from("audit_logs").insert({
    actor_id: actorId,
    action,
    entity,
    entity_id: entityId,
    metadata: metadata as never,
  });
}

export async function recordLeadEvent(
  leadId: string,
  fromStatus: string | null,
  toStatus: string | null,
  note?: string,
) {
  await supabaseAdmin.from("lead_events").insert({
    lead_id: leadId,
    from_status: fromStatus as never,
    to_status: toStatus as never,
    note: note ?? null,
  });
}
