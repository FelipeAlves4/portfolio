import { supabaseAdmin } from "./platform.server";

export async function assertAdmin(userId: string) {
  const { data } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  if (!data) throw new Error("Acesso restrito a administradores.");
}

export async function adminOverview() {
  const [leads, costs, opportunities, connections, campaigns, events] = await Promise.all([
    supabaseAdmin.from("leads").select("id, status, created_at, attributed_cost, source, campaign"),
    supabaseAdmin.from("marketing_costs").select("spend, leads"),
    supabaseAdmin.from("connection_opportunities").select("id, status"),
    supabaseAdmin.from("connections").select("id, amount, attributed_cost, stage"),
    supabaseAdmin.from("campaigns").select("*"),
    supabaseAdmin
      .from("conversion_events")
      .select("event_type, created_at")
      .order("created_at", { ascending: false })
      .limit(50),
  ]);

  const leadRows = leads.data ?? [];
  const costRows = costs.data ?? [];
  const connRows = connections.data ?? [];

  const spend = costRows.reduce((acc, c) => acc + Number(c.spend), 0);
  const totalLeads = leadRows.length;
  const qualified = leadRows.filter((l) =>
    ["QUALIFIED", "READY_FOR_MATCHING", "OPPORTUNITY_CREATED", "CONNECTED", "CONVERTED"].includes(l.status),
  ).length;
  const revenue = connRows.reduce((acc, c) => acc + Number(c.amount), 0);
  const attributedCost = connRows.reduce((acc, c) => acc + Number(c.attributed_cost), 0);
  const scheduled = connRows.filter((c) =>
    ["APPOINTMENT_SCHEDULED", "TREATMENT_STARTED"].includes(c.stage),
  ).length;
  const started = connRows.filter((c) => c.stage === "TREATMENT_STARTED").length;

  return {
    spend,
    totalLeads,
    cpl: totalLeads ? spend / totalLeads : 0,
    qualified,
    opportunities: (opportunities.data ?? []).length,
    connections: connRows.length,
    revenue,
    grossMargin: revenue - attributedCost,
    scheduleRate: connRows.length ? (scheduled / connRows.length) * 100 : 0,
    treatmentRate: connRows.length ? (started / connRows.length) * 100 : 0,
    funnel: [
      { stage: "Leads", value: totalLeads },
      { stage: "Qualificados", value: qualified },
      { stage: "Oportunidades", value: (opportunities.data ?? []).length },
      { stage: "Conexões", value: connRows.length },
      { stage: "Consultas", value: scheduled },
      { stage: "Atendimentos", value: started },
    ],
    campaigns: (campaigns.data ?? []).map((c) => ({
      id: c.id,
      name: c.name,
      channel: c.channel,
      status: c.status,
    })),
    recentEvents: (events.data ?? []).map((e) => ({
      type: e.event_type,
      createdAt: e.created_at,
    })),
  };
}

export async function adminLeads() {
  const { data } = await supabaseAdmin
    .from("leads")
    .select("id, first_name, status, source, campaign, attributed_cost, created_at")
    .order("created_at", { ascending: false })
    .limit(100);
  return (data ?? []).map((l) => ({
    id: l.id,
    firstName: l.first_name,
    status: l.status,
    source: l.source,
    campaign: l.campaign,
    attributedCost: Number(l.attributed_cost),
    createdAt: l.created_at,
  }));
}

export async function adminPsychologists() {
  const { data } = await supabaseAdmin
    .from("psychologist_profiles")
    .select("id, display_name, crp, crp_state, city, state, specialties, quality_score, is_demo")
    .order("created_at", { ascending: false })
    .limit(100);
  return data ?? [];
}

export async function adminOpportunities() {
  const { data } = await supabaseAdmin
    .from("connection_opportunities")
    .select("id, status, need, modality, city, closes_at, selected_amount, created_at")
    .order("created_at", { ascending: false })
    .limit(100);
  return data ?? [];
}
