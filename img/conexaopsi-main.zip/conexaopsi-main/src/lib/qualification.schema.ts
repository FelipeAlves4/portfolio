import { z } from "zod";

export const qualificationSchema = z.object({
  firstName: z.string().trim().min(2).max(60),
  whatsapp: z.string().trim().min(10).max(20),
  need: z.string().trim().min(2).max(60),
  needDetails: z.string().trim().max(600).optional().nullable(),
  professionalPreference: z.string().trim().max(40),
  modality: z.string().trim().max(20),
  city: z.string().trim().max(80).optional().nullable(),
  state: z.string().trim().max(40).optional().nullable(),
  availability: z.array(z.string().max(30)).max(6),
  startIntent: z.string().trim().max(40),
  priceRange: z.string().trim().max(30),
  frequency: z.string().trim().max(30),
  consent: z.object({
    storage: z.literal(true),
    matching: z.literal(true),
    sharing: z.literal(true),
  }),
  tracking: z
    .object({
      utm_source: z.string().max(120).optional().nullable(),
      utm_medium: z.string().max(120).optional().nullable(),
      utm_campaign: z.string().max(120).optional().nullable(),
      utm_content: z.string().max(120).optional().nullable(),
      utm_term: z.string().max(120).optional().nullable(),
      landing_page: z.string().max(300).optional().nullable(),
      click_id: z.string().max(160).optional().nullable(),
    })
    .optional(),
});

export type QualificationInput = z.infer<typeof qualificationSchema>;
