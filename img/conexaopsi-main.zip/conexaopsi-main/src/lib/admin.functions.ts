import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const fetchAdminOverview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin, adminOverview, adminLeads, adminPsychologists, adminOpportunities } =
      await import("./admin.server");
    await assertAdmin(context.userId);
    const [overview, leads, psychologists, opportunities] = await Promise.all([
      adminOverview(),
      adminLeads(),
      adminPsychologists(),
      adminOpportunities(),
    ]);
    return { overview, leads, psychologists, opportunities };
  });

export const checkIsAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("./admin.server");
    try {
      await assertAdmin(context.userId);
      return { isAdmin: true };
    } catch {
      return { isAdmin: false };
    }
  });
