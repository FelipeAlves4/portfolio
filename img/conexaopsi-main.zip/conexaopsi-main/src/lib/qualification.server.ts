import { type QualificationInput } from "./qualification.schema";
import { loadSettings, recordAudit, recordConversion, recordLeadEvent, supabaseAdmin } from "./platform.server";



const CONSENT_TEXT =
  "Autorizo o armazenamento das informações fornecidas, sua utilização para encontrar profissionais compatíveis e o compartilhamento das informações autorizadas com o profissional selecionado.";

export async function createQualifiedLead(input: QualificationInput) {
  const settings = await loadSettings();
  const tracking = input.tracking ?? {};

  const { data: lead, error: leadError } = await supabaseAdmin
    .from("leads")
    .insert({
      first_name: input.firstName,
      whatsapp: input.whatsapp,
      status: "READY_FOR_MATCHING",
      source: tracking.utm_source ?? "Orgânico",
      medium: tracking.utm_medium ?? null,
      campaign: tracking.utm_campaign ?? null,
      utm_source: tracking.utm_source ?? null,
      utm_medium: tracking.utm_medium ?? null,
      utm_campaign: tracking.utm_campaign ?? null,
      utm_content: tracking.utm_content ?? null,
      utm_term: tracking.utm_term ?? null,
      landing_page: tracking.landing_page ?? "/",
      click_id: tracking.click_id ?? null,
    })
    .select("id")
    .single();

  if (leadError || !lead) throw new Error("Não foi possível registrar suas informações.");

  await supabaseAdmin.from("lead_consents").insert({
    lead_id: lead.id,
    storage_consent: input.consent.storage,
    matching_consent: input.consent.matching,
    sharing_consent: input.consent.sharing,
    consent_text: CONSENT_TEXT,
  });

  const { data: profile, error: profileError } = await supabaseAdmin
    .from("connection_profiles")
    .insert({
      lead_id: lead.id,
      need: input.need,
      need_details: input.needDetails ?? null,
      professional_preference: input.professionalPreference,
      modality: input.modality,
      city: input.city ?? null,
      state: input.state ?? null,
      availability: input.availability,
      start_intent: input.startIntent,
      price_range: input.priceRange,
      frequency: input.frequency,
    })
    .select("*")
    .single();

  if (profileError || !profile) throw new Error("Não foi possível criar o perfil de conexão.");

  await recordLeadEvent(lead.id, "NEW", "READY_FOR_MATCHING", "Pré-qualificação concluída");
  await recordConversion("LEAD_CREATED", "lead", lead.id, "landing");
  await recordConversion("LEAD_QUALIFIED", "lead", lead.id, "landing");

  const closesAt = new Date(Date.now() + settings.connectionWindowSeconds * 1000).toISOString();
  const { data: opportunity } = await supabaseAdmin
    .from("connection_opportunities")
    .insert({
      connection_profile_id: profile.id,
      status: "OPEN",
      need: profile.need,
      need_details: profile.need_details,
      modality: profile.modality,
      city: profile.city,
      state: profile.state,
      professional_preference: profile.professional_preference,
      availability: profile.availability,
      start_intent: profile.start_intent,
      price_range: profile.price_range,
      frequency: profile.frequency,
      opens_at: new Date().toISOString(),
      closes_at: closesAt,
    })
    .select("id")
    .single();

  if (opportunity) {
    await supabaseAdmin.from("leads").update({ status: "OPPORTUNITY_CREATED" }).eq("id", lead.id);
    await recordLeadEvent(lead.id, "READY_FOR_MATCHING", "OPPORTUNITY_CREATED", "Oportunidade de conexão criada");
    await recordConversion("OPPORTUNITY_CREATED", "opportunity", opportunity.id, "landing");
  }

  await supabaseAdmin.from("whatsapp_conversations").insert({
    lead_id: lead.id,
    status: "PENDING_INTEGRATION",
  });

  await recordAudit(null, "lead.created", "lead", lead.id, { channel: "landing" });

  return {
    connectionProfile: {
      need: profile.need,
      modality: profile.modality,
      city: profile.city,
      state: profile.state,
      professionalPreference: profile.professional_preference,
      availability: profile.availability,
      startIntent: profile.start_intent,
      priceRange: profile.price_range,
      frequency: profile.frequency,
    },
  };
}
