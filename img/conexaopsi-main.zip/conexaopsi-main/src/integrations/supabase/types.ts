export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          entity: string
          entity_id: string | null
          id: string
          metadata: Json
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          entity: string
          entity_id?: string | null
          id?: string
          metadata?: Json
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          entity?: string
          entity_id?: string | null
          id?: string
          metadata?: Json
        }
        Relationships: []
      }
      automation_flows: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          name: string
          steps: Json
          trigger_status: Database["public"]["Enums"]["lead_status"] | null
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          steps?: Json
          trigger_status?: Database["public"]["Enums"]["lead_status"] | null
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          steps?: Json
          trigger_status?: Database["public"]["Enums"]["lead_status"] | null
        }
        Relationships: []
      }
      campaigns: {
        Row: {
          channel: string
          created_at: string
          external_id: string | null
          id: string
          name: string
          status: string
          updated_at: string
        }
        Insert: {
          channel: string
          created_at?: string
          external_id?: string | null
          id?: string
          name: string
          status?: string
          updated_at?: string
        }
        Update: {
          channel?: string
          created_at?: string
          external_id?: string | null
          id?: string
          name?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      connection_events: {
        Row: {
          connection_id: string
          created_at: string
          id: string
          note: string | null
          stage: Database["public"]["Enums"]["connection_stage"]
        }
        Insert: {
          connection_id: string
          created_at?: string
          id?: string
          note?: string | null
          stage: Database["public"]["Enums"]["connection_stage"]
        }
        Update: {
          connection_id?: string
          created_at?: string
          id?: string
          note?: string | null
          stage?: Database["public"]["Enums"]["connection_stage"]
        }
        Relationships: [
          {
            foreignKeyName: "connection_events_connection_id_fkey"
            columns: ["connection_id"]
            isOneToOne: false
            referencedRelation: "connections"
            referencedColumns: ["id"]
          },
        ]
      }
      connection_opportunities: {
        Row: {
          availability: string[]
          base_price: number
          city: string | null
          closes_at: string
          connection_profile_id: string
          created_at: string
          frequency: string | null
          id: string
          is_demo: boolean
          modality: string
          need: string
          need_details: string | null
          opens_at: string
          payment_due_at: string | null
          price_range: string | null
          professional_preference: string | null
          selected_amount: number | null
          selected_user_id: string | null
          start_intent: string | null
          state: string | null
          status: Database["public"]["Enums"]["opportunity_status"]
          updated_at: string
        }
        Insert: {
          availability?: string[]
          base_price?: number
          city?: string | null
          closes_at?: string
          connection_profile_id: string
          created_at?: string
          frequency?: string | null
          id?: string
          is_demo?: boolean
          modality: string
          need: string
          need_details?: string | null
          opens_at?: string
          payment_due_at?: string | null
          price_range?: string | null
          professional_preference?: string | null
          selected_amount?: number | null
          selected_user_id?: string | null
          start_intent?: string | null
          state?: string | null
          status?: Database["public"]["Enums"]["opportunity_status"]
          updated_at?: string
        }
        Update: {
          availability?: string[]
          base_price?: number
          city?: string | null
          closes_at?: string
          connection_profile_id?: string
          created_at?: string
          frequency?: string | null
          id?: string
          is_demo?: boolean
          modality?: string
          need?: string
          need_details?: string | null
          opens_at?: string
          payment_due_at?: string | null
          price_range?: string | null
          professional_preference?: string | null
          selected_amount?: number | null
          selected_user_id?: string | null
          start_intent?: string | null
          state?: string | null
          status?: Database["public"]["Enums"]["opportunity_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "connection_opportunities_connection_profile_id_fkey"
            columns: ["connection_profile_id"]
            isOneToOne: false
            referencedRelation: "connection_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      connection_profiles: {
        Row: {
          availability: string[]
          city: string | null
          created_at: string
          frequency: string | null
          id: string
          lead_id: string
          modality: string
          need: string
          need_details: string | null
          price_range: string | null
          professional_preference: string
          start_intent: string | null
          state: string | null
          updated_at: string
        }
        Insert: {
          availability?: string[]
          city?: string | null
          created_at?: string
          frequency?: string | null
          id?: string
          lead_id: string
          modality?: string
          need: string
          need_details?: string | null
          price_range?: string | null
          professional_preference?: string
          start_intent?: string | null
          state?: string | null
          updated_at?: string
        }
        Update: {
          availability?: string[]
          city?: string | null
          created_at?: string
          frequency?: string | null
          id?: string
          lead_id?: string
          modality?: string
          need?: string
          need_details?: string | null
          price_range?: string | null
          professional_preference?: string
          start_intent?: string | null
          state?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "connection_profiles_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      connections: {
        Row: {
          amount: number
          attributed_cost: number
          compatibility_score: number
          contact_unlocked: boolean
          created_at: string
          id: string
          lead_id: string
          opportunity_id: string
          stage: Database["public"]["Enums"]["connection_stage"]
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          attributed_cost?: number
          compatibility_score?: number
          contact_unlocked?: boolean
          created_at?: string
          id?: string
          lead_id: string
          opportunity_id: string
          stage?: Database["public"]["Enums"]["connection_stage"]
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          attributed_cost?: number
          compatibility_score?: number
          contact_unlocked?: boolean
          created_at?: string
          id?: string
          lead_id?: string
          opportunity_id?: string
          stage?: Database["public"]["Enums"]["connection_stage"]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "connections_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "connections_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "connection_opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      conversion_events: {
        Row: {
          created_at: string
          entity: string
          entity_id: string | null
          event_type: string
          id: string
          metadata: Json
          origin: string | null
        }
        Insert: {
          created_at?: string
          entity: string
          entity_id?: string | null
          event_type: string
          id?: string
          metadata?: Json
          origin?: string | null
        }
        Update: {
          created_at?: string
          entity?: string
          entity_id?: string | null
          event_type?: string
          id?: string
          metadata?: Json
          origin?: string | null
        }
        Relationships: []
      }
      credit_transactions: {
        Row: {
          amount: number
          connection_id: string | null
          created_at: string
          description: string | null
          id: string
          kind: string
          user_id: string
        }
        Insert: {
          amount: number
          connection_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          kind: string
          user_id: string
        }
        Update: {
          amount?: number
          connection_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          kind?: string
          user_id?: string
        }
        Relationships: []
      }
      interest_manifestations: {
        Row: {
          compatibility_score: number
          created_at: string
          final_score: number
          id: string
          opportunity_id: string
          priority_amount: number
          user_id: string
        }
        Insert: {
          compatibility_score?: number
          created_at?: string
          final_score?: number
          id?: string
          opportunity_id: string
          priority_amount: number
          user_id: string
        }
        Update: {
          compatibility_score?: number
          created_at?: string
          final_score?: number
          id?: string
          opportunity_id?: string
          priority_amount?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "interest_manifestations_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "connection_opportunities"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_consents: {
        Row: {
          consent_text: string | null
          created_at: string
          id: string
          lead_id: string
          matching_consent: boolean
          revoked_at: string | null
          sharing_consent: boolean
          storage_consent: boolean
        }
        Insert: {
          consent_text?: string | null
          created_at?: string
          id?: string
          lead_id: string
          matching_consent?: boolean
          revoked_at?: string | null
          sharing_consent?: boolean
          storage_consent?: boolean
        }
        Update: {
          consent_text?: string | null
          created_at?: string
          id?: string
          lead_id?: string
          matching_consent?: boolean
          revoked_at?: string | null
          sharing_consent?: boolean
          storage_consent?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "lead_consents_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_events: {
        Row: {
          created_at: string
          from_status: Database["public"]["Enums"]["lead_status"] | null
          id: string
          lead_id: string
          metadata: Json
          note: string | null
          to_status: Database["public"]["Enums"]["lead_status"] | null
        }
        Insert: {
          created_at?: string
          from_status?: Database["public"]["Enums"]["lead_status"] | null
          id?: string
          lead_id: string
          metadata?: Json
          note?: string | null
          to_status?: Database["public"]["Enums"]["lead_status"] | null
        }
        Update: {
          created_at?: string
          from_status?: Database["public"]["Enums"]["lead_status"] | null
          id?: string
          lead_id?: string
          metadata?: Json
          note?: string | null
          to_status?: Database["public"]["Enums"]["lead_status"] | null
        }
        Relationships: [
          {
            foreignKeyName: "lead_events_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      leads: {
        Row: {
          ad_id: string | null
          adset_id: string | null
          attributed_cost: number
          campaign: string | null
          campaign_id: string | null
          click_id: string | null
          created_at: string
          email: string | null
          first_name: string
          id: string
          is_demo: boolean
          keyword: string | null
          landing_page: string | null
          medium: string | null
          source: string | null
          status: Database["public"]["Enums"]["lead_status"]
          updated_at: string
          utm_campaign: string | null
          utm_content: string | null
          utm_medium: string | null
          utm_source: string | null
          utm_term: string | null
          whatsapp: string
        }
        Insert: {
          ad_id?: string | null
          adset_id?: string | null
          attributed_cost?: number
          campaign?: string | null
          campaign_id?: string | null
          click_id?: string | null
          created_at?: string
          email?: string | null
          first_name: string
          id?: string
          is_demo?: boolean
          keyword?: string | null
          landing_page?: string | null
          medium?: string | null
          source?: string | null
          status?: Database["public"]["Enums"]["lead_status"]
          updated_at?: string
          utm_campaign?: string | null
          utm_content?: string | null
          utm_medium?: string | null
          utm_source?: string | null
          utm_term?: string | null
          whatsapp: string
        }
        Update: {
          ad_id?: string | null
          adset_id?: string | null
          attributed_cost?: number
          campaign?: string | null
          campaign_id?: string | null
          click_id?: string | null
          created_at?: string
          email?: string | null
          first_name?: string
          id?: string
          is_demo?: boolean
          keyword?: string | null
          landing_page?: string | null
          medium?: string | null
          source?: string | null
          status?: Database["public"]["Enums"]["lead_status"]
          updated_at?: string
          utm_campaign?: string | null
          utm_content?: string | null
          utm_medium?: string | null
          utm_source?: string | null
          utm_term?: string | null
          whatsapp?: string
        }
        Relationships: []
      }
      marketing_costs: {
        Row: {
          campaign_id: string | null
          created_at: string
          id: string
          leads: number
          reference_date: string
          spend: number
        }
        Insert: {
          campaign_id?: string | null
          created_at?: string
          id?: string
          leads?: number
          reference_date?: string
          spend?: number
        }
        Update: {
          campaign_id?: string | null
          created_at?: string
          id?: string
          leads?: number
          reference_date?: string
          spend?: number
        }
        Relationships: [
          {
            foreignKeyName: "marketing_costs_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
        ]
      }
      payments: {
        Row: {
          amount: number
          connection_id: string | null
          created_at: string
          id: string
          provider: string
          provider_reference: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          connection_id?: string | null
          created_at?: string
          id?: string
          provider?: string
          provider_reference?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          connection_id?: string | null
          created_at?: string
          id?: string
          provider?: string
          provider_reference?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      platform_settings: {
        Row: {
          description: string | null
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          description?: string | null
          key: string
          updated_at?: string
          value: Json
        }
        Update: {
          description?: string | null
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      psychologist_preferences: {
        Row: {
          audiences: string[]
          cities: string[]
          created_at: string
          id: string
          in_person: boolean
          needs: string[]
          online_only: boolean
          price_ranges: string[]
          receive_opportunities: boolean
          schedules: string[]
          specialties: string[]
          states: string[]
          updated_at: string
          user_id: string
        }
        Insert: {
          audiences?: string[]
          cities?: string[]
          created_at?: string
          id?: string
          in_person?: boolean
          needs?: string[]
          online_only?: boolean
          price_ranges?: string[]
          receive_opportunities?: boolean
          schedules?: string[]
          specialties?: string[]
          states?: string[]
          updated_at?: string
          user_id: string
        }
        Update: {
          audiences?: string[]
          cities?: string[]
          created_at?: string
          id?: string
          in_person?: boolean
          needs?: string[]
          online_only?: boolean
          price_ranges?: string[]
          receive_opportunities?: boolean
          schedules?: string[]
          specialties?: string[]
          states?: string[]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      psychologist_profiles: {
        Row: {
          approaches: string[]
          audiences: string[]
          availability: string[]
          bio: string | null
          city: string | null
          created_at: string
          crp: string | null
          crp_state: string | null
          display_name: string
          education: string | null
          gender: string | null
          id: string
          is_demo: boolean
          max_price: number | null
          min_price: number | null
          modalities: string[]
          online_care: boolean
          photo_url: string | null
          quality_score: number
          specialties: string[]
          state: string | null
          updated_at: string
          user_id: string | null
          years_experience: number | null
        }
        Insert: {
          approaches?: string[]
          audiences?: string[]
          availability?: string[]
          bio?: string | null
          city?: string | null
          created_at?: string
          crp?: string | null
          crp_state?: string | null
          display_name: string
          education?: string | null
          gender?: string | null
          id?: string
          is_demo?: boolean
          max_price?: number | null
          min_price?: number | null
          modalities?: string[]
          online_care?: boolean
          photo_url?: string | null
          quality_score?: number
          specialties?: string[]
          state?: string | null
          updated_at?: string
          user_id?: string | null
          years_experience?: number | null
        }
        Update: {
          approaches?: string[]
          audiences?: string[]
          availability?: string[]
          bio?: string | null
          city?: string | null
          created_at?: string
          crp?: string | null
          crp_state?: string | null
          display_name?: string
          education?: string | null
          gender?: string | null
          id?: string
          is_demo?: boolean
          max_price?: number | null
          min_price?: number | null
          modalities?: string[]
          online_care?: boolean
          photo_url?: string | null
          quality_score?: number
          specialties?: string[]
          state?: string | null
          updated_at?: string
          user_id?: string | null
          years_experience?: number | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      wallets: {
        Row: {
          balance: number
          created_at: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          balance?: number
          created_at?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          balance?: number
          created_at?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      whatsapp_conversations: {
        Row: {
          created_at: string
          external_id: string | null
          id: string
          lead_id: string | null
          provider: string
          status: string
        }
        Insert: {
          created_at?: string
          external_id?: string | null
          id?: string
          lead_id?: string | null
          provider?: string
          status?: string
        }
        Update: {
          created_at?: string
          external_id?: string | null
          id?: string
          lead_id?: string | null
          provider?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_conversations_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_messages: {
        Row: {
          body: string | null
          conversation_id: string | null
          created_at: string
          delivery_status: string | null
          direction: string
          id: string
          template: string | null
        }
        Insert: {
          body?: string | null
          conversation_id?: string | null
          created_at?: string
          delivery_status?: string | null
          direction: string
          id?: string
          template?: string | null
        }
        Update: {
          body?: string | null
          conversation_id?: string | null
          created_at?: string
          delivery_status?: string | null
          direction?: string
          id?: string
          template?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "whatsapp_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "psychologist"
      connection_stage:
        | "CONNECTION_MADE"
        | "CONTACT_PENDING"
        | "CONTACTED"
        | "APPOINTMENT_SCHEDULED"
        | "TREATMENT_STARTED"
        | "NO_CONTACT"
        | "GAVE_UP"
        | "NOT_COMPATIBLE"
      lead_status:
        | "NEW"
        | "CONSENTED"
        | "QUALIFYING"
        | "QUALIFIED"
        | "WARMING"
        | "READY_FOR_MATCHING"
        | "OPPORTUNITY_CREATED"
        | "CONNECTED"
        | "CONVERTED"
        | "INVALID"
        | "UNRESPONSIVE"
        | "CANCELLED"
      opportunity_status:
        | "DRAFT"
        | "OPEN"
        | "SELECTING"
        | "PROFESSIONAL_SELECTED"
        | "PAYMENT_PENDING"
        | "PAID"
        | "CONTACT_UNLOCKED"
        | "CONNECTED"
        | "EXPIRED"
        | "NO_CANDIDATES"
        | "PAYMENT_EXPIRED"
        | "CANCELLED"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "psychologist"],
      connection_stage: [
        "CONNECTION_MADE",
        "CONTACT_PENDING",
        "CONTACTED",
        "APPOINTMENT_SCHEDULED",
        "TREATMENT_STARTED",
        "NO_CONTACT",
        "GAVE_UP",
        "NOT_COMPATIBLE",
      ],
      lead_status: [
        "NEW",
        "CONSENTED",
        "QUALIFYING",
        "QUALIFIED",
        "WARMING",
        "READY_FOR_MATCHING",
        "OPPORTUNITY_CREATED",
        "CONNECTED",
        "CONVERTED",
        "INVALID",
        "UNRESPONSIVE",
        "CANCELLED",
      ],
      opportunity_status: [
        "DRAFT",
        "OPEN",
        "SELECTING",
        "PROFESSIONAL_SELECTED",
        "PAYMENT_PENDING",
        "PAID",
        "CONTACT_UNLOCKED",
        "CONNECTED",
        "EXPIRED",
        "NO_CANDIDATES",
        "PAYMENT_EXPIRED",
        "CANCELLED",
      ],
    },
  },
} as const
