import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { HeartHandshake } from "lucide-react";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4 sm:px-6">
        <Link to="/" className="flex items-center gap-2">
          <span className="surface-primary flex size-9 items-center justify-center rounded-xl">
            <HeartHandshake className="size-5 text-primary-foreground" />
          </span>
          <span className="text-base font-semibold tracking-tight">Conexão Psi</span>
        </Link>
        <nav className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
          <Link to="/" hash="como-funciona" className="transition-colors hover:text-foreground">
            Como funciona
          </Link>
          <Link to="/" hash="privacidade" className="transition-colors hover:text-foreground">
            Privacidade
          </Link>
          <Link to="/" hash="faq" className="transition-colors hover:text-foreground">
            Dúvidas
          </Link>
        </nav>
        <div className="flex items-center gap-2">
          <Button asChild variant="ghost" size="sm">
            <Link to="/auth">Sou psicólogo</Link>
          </Button>
          <Button asChild size="sm">
            <Link to="/qualificacao">Encontrar um profissional</Link>
          </Button>
        </div>
      </div>
    </header>
  );
}
