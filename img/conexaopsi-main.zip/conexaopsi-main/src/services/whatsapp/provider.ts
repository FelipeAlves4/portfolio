/**
 * Camada de abstração para WhatsApp Business API.
 * INTEGRAÇÃO PENDENTE: nenhuma integração real é simulada aqui.
 * A implementação concreta deve ser registrada quando a API estiver disponível.
 */

export type WhatsAppMessage = {
  to: string;
  body?: string;
  template?: string;
  variables?: Record<string, string>;
};

export type WhatsAppDeliveryStatus = "queued" | "sent" | "delivered" | "read" | "failed";

export type WhatsAppInboundMessage = {
  from: string;
  body: string;
  receivedAt: string;
  externalId: string;
};

export interface WhatsAppProvider {
  readonly name: string;
  readonly isConfigured: boolean;
  sendMessage(message: WhatsAppMessage): Promise<{ externalId: string }>;
  getDeliveryStatus(externalId: string): Promise<WhatsAppDeliveryStatus>;
  parseWebhook(payload: unknown): WhatsAppInboundMessage[];
}

export class PendingIntegrationWhatsAppProvider implements WhatsAppProvider {
  readonly name = "pending-integration";
  readonly isConfigured = false;

  async sendMessage(): Promise<{ externalId: string }> {
    throw new Error("Integração com WhatsApp Business API pendente.");
  }

  async getDeliveryStatus(): Promise<WhatsAppDeliveryStatus> {
    throw new Error("Integração com WhatsApp Business API pendente.");
  }

  parseWebhook(): WhatsAppInboundMessage[] {
    return [];
  }
}

let provider: WhatsAppProvider = new PendingIntegrationWhatsAppProvider();

export function registerWhatsAppProvider(next: WhatsAppProvider) {
  provider = next;
}

export function getWhatsAppProvider(): WhatsAppProvider {
  return provider;
}

export function whatsappLink(phone: string, message?: string): string {
  const digits = phone.replace(/\D/g, "");
  const query = message ? `?text=${encodeURIComponent(message)}` : "";
  return `https://wa.me/${digits}${query}`;
}
