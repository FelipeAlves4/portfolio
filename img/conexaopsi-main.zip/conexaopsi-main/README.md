# Conecta Psi

Quero que você crie uma aplicação SaaS completa chamada provisoriamente Conexão Psi, voltada para conectar pessoas que estão procurando atendimento psicológico a psicólogos compatíveis.

IMPORTANTE: não estamos criando um diretório de psicólogos, nem um marketplace tradicional, nem um CRM simples.

O produto é uma máquina de geração, qualificação e distribuição de demanda.

A plataforma deve:

captar pessoas interessadas em atendimento psicológico;

realizar uma pré-qualificação humanizada;

criar um Perfil de Conexão;

encontrar psicólogos compatíveis;

criar uma Oportunidade de Conexão;

permitir que psicólogos manifestem interesse;

considerar compatibilidade + investimento de prioridade;

selecionar o profissional mais adequado;

cobrar pela conexão;

liberar os dados do paciente somente após pagamento;

acompanhar contato, agendamento e início do atendimento;

gerar métricas de marketing, aquisição e conversão.

1. LINGUAGEM OBRIGATÓRIA DO PRODUTO

A plataforma deve transmitir cuidado, acolhimento e compatibilidade.

Nunca utilizar:

comprar paciente;

vender paciente;

leilão;

lance;

arrematar;

disputa por paciente;

cliente vendido;

paciente vendido;

vencedor.

Utilizar:

oportunidade de conexão;

conexão compatível;

manifestação de interesse;

prioridade de conexão;

investimento de conexão;

profissional selecionado;

conexão direcionada;

conexão realizada;

oportunidade de atendimento.

Mesmo que internamente exista uma lógica parecida com prioridade financeira, isso nunca deve parecer um leilão para o usuário.

2. PERFIS DE USUÁRIO

A aplicação terá inicialmente três perfis:

Paciente / Lead

Não precisa necessariamente criar uma conta.

Ele entra por uma landing page, informa seus dados, autoriza o tratamento das informações e passa pela pré-qualificação.

Psicólogo

Possui conta própria.

Deve poder:

configurar perfil;

informar CRP;

especialidades;

modalidades;

valores;

cidades;

disponibilidade;

preferências;

visualizar oportunidades;

manifestar interesse;

utilizar créditos;

pagar por conexões;

acessar conexões adquiridas;

informar evolução da conexão.

Administrador

Gerencia:

leads;

psicólogos;

campanhas;

anúncios;

oportunidades;

conexões;

pagamentos;

créditos;

métricas;

conversões;

configurações do sistema.

3. STACK

Utilize preferencialmente:

React;

TypeScript;

Tailwind CSS;

shadcn/ui;

Supabase;

Supabase Auth;

PostgreSQL do Supabase;

Row Level Security;

Supabase Storage caso necessário.

Organize o projeto com arquitetura limpa e componentes reutilizáveis.

Não crie tudo em um único arquivo.

Separe:

components;

pages;

hooks;

services;

types;

utils;

database;

features.

4. DESIGN

Quero um produto moderno, profissional e acolhedor.

Evitar aparência:

hospitalar;

excessivamente corporativa;

infantil;

genérica de dashboard SaaS;

visual de marketplace;

visual de sistema financeiro.

A identidade deve transmitir:

confiança;

tranquilidade;

cuidado;

tecnologia;

profissionalismo.

Utilize uma paleta baseada em:

azul suave;

verde/azul petróleo;

branco;

tons claros neutros.

Cards com:

bordas suaves;

bastante espaçamento;

sombras discretas;

cantos arredondados.

Interface responsiva para desktop e mobile.

5. LANDING PAGE DO PACIENTE

Criar página pública com foco em conversão.

Headline sugerida:

Encontre um psicólogo que combine com o que você está procurando.

Subheadline:

Conte para a gente um pouco sobre o que você busca e vamos encontrar profissionais compatíveis com suas necessidades, preferências e disponibilidade.

CTA:

Encontrar um profissional

Seções:

como funciona;

atendimento online ou presencial;

processo simples;

profissionais compatíveis;

privacidade das informações;

perguntas frequentes.

O paciente não deve visualizar uma lista gigante de profissionais.

Ele deve iniciar o processo de qualificação.

6. PRÉ-QUALIFICAÇÃO

Criar uma experiência de questionário conversacional, parecida com chat.

Exemplo de início:

Olá! 💙 Vamos ajudar você a encontrar um profissional que combine com o que você está procurando.

Posso fazer algumas perguntas rápidas?

Perguntar:

Nome

Primeiro nome.

WhatsApp

Telefone com DDD.

Necessidade

Opções:

ansiedade/estresse;

relacionamento;

terapia de casal;

luto;

autoestima;

família;

carreira;

adolescência;

questões emocionais;

outro.

Permitir texto complementar opcional.

Não utilizar linguagem de diagnóstico.

Utilizar sempre:

Necessidade informada

e não:

Diagnóstico

Preferência de profissional

psicólogo homem;

psicóloga mulher;

indiferente.

Modalidade

online;

presencial;

indiferente.

Localização

Caso escolha presencial:

cidade;

estado/região.

Disponibilidade

manhã;

tarde;

noite;

finais de semana;

horários específicos.

Quando pretende começar

agora;

nesta semana;

próximas semanas;

estou apenas pesquisando.

Faixa de investimento por sessão

até R$100;

R$100–150;

R$150–200;

R$200–300;

acima de R$300.

Frequência pretendida

semanal;

quinzenal;

ainda não sei.

7. CONSENTIMENTO

Antes de finalizar, exibir consentimento claro.

O usuário deve autorizar:

armazenamento das informações fornecidas;

utilização para encontrar profissionais compatíveis;

compartilhamento das informações autorizadas com um psicólogo selecionado.

Não liberar informações pessoais para psicólogos antes da conexão ser confirmada.

8. PERFIL DE CONEXÃO

Após concluir o questionário, gerar internamente um:

Perfil de Conexão

Exemplo:

Atendimento:
Online

Localização:
São Paulo

Necessidade informada:
Ansiedade/estresse

Preferência:
Psicóloga mulher

Disponibilidade:
Noite

Pretende começar:
Esta semana

Faixa de investimento:
R$150–200

Frequência:
Semanal

Status:

Pronto para encontrar profissionais compatíveis

9. ESTADOS DO LEAD

Criar estrutura de status como:

NEW;

CONSENTED;

QUALIFYING;

QUALIFIED;

WARMING;

READY_FOR_MATCHING;

OPPORTUNITY_CREATED;

CONNECTED;

CONVERTED;

INVALID;

UNRESPONSIVE;

CANCELLED.

Criar timeline interna registrando mudanças.

10. PAINEL DO PSICÓLOGO

Criar dashboard após login.

Menu lateral:

Visão geral;

Oportunidades;

Minhas conexões;

Créditos;

Perfil profissional;

Preferências;

Histórico;

Configurações.

11. DASHBOARD DO PSICÓLOGO

Exibir:

Novas oportunidades

Quantidade disponível.

Conexões realizadas

Mês atual.

Contatos realizados

Quantidade.

Consultas agendadas

Quantidade.

Pacientes iniciados

Quantidade.

Saldo

Exemplo:

R$380 em créditos

Adicionar gráficos simples de evolução.

12. PERFIL PROFISSIONAL

Campos:

nome;

foto;

CRP;

estado do CRP;

biografia;

formação;

anos de experiência;

especialidades;

públicos atendidos;

modalidades;

cidade;

estado;

atendimento online;

valor mínimo;

valor máximo;

disponibilidade;

horários;

gênero do profissional;

abordagens terapêuticas.

Criar indicador de:

Perfil 85% completo

13. PREFERÊNCIAS DE OPORTUNIDADES

O psicólogo configura quais oportunidades deseja receber.

Campos:

especialidades;

tipos de necessidade;

cidades;

estados;

somente online;

presencial;

faixa de investimento;

horários;

preferência etária;

público atendido.

Adicionar switch:

Receber novas oportunidades compatíveis

14. OPORTUNIDADES

Criar página:

Oportunidades de conexão

Cada oportunidade deve aparecer em card.

Exemplo:

💙 Nova oportunidade de conexão

Compatibilidade:

92%

Dados visíveis:

Atendimento: Online

Localização: São Paulo

Necessidade informada: Ansiedade/estresse

Preferência: Psicóloga mulher

Disponibilidade: Noite

Pretende começar: Esta semana

Faixa de investimento: R$150–200

Frequência pretendida: Semanal

Mostrar:

Janela de conexão

04:32

Botão:

Manifestar interesse

NÃO mostrar:

nome;

telefone;

WhatsApp;

e-mail;

endereço;

qualquer dado pessoal identificável.

15. MANIFESTAÇÃO DE INTERESSE

Ao clicar em:

Manifestar interesse

abrir modal:

Prioridade de conexão

Texto:

Defina quanto você deseja investir para obter prioridade nesta oportunidade. O valor não é o único critério utilizado para direcionar a conexão. A compatibilidade entre o seu perfil e as necessidades informadas também é considerada.

Campo:

Investimento de conexão

R$ ______

Mostrar:

Saldo disponível:
R$500

Sugestões:

R$80;

R$100;

R$120;

outro valor.

Botão:

Confirmar manifestação de interesse

Nunca utilizar a palavra lance.

16. MATCHING

Criar arquitetura preparada para calcular:

Compatibility Score

de 0 a 100.

Fatores iniciais:

especialidade: 25;

modalidade: 15;

disponibilidade: 15;

faixa de preço: 15;

preferências: 10;

localização: 10;

qualidade/perfil profissional: 10.

Antes do cálculo, deve existir filtro de elegibilidade.

Exemplo:

Paciente deseja atendimento presencial em São Paulo.

Psicólogo atende somente online.

Resultado:

Não elegível.

17. PRIORIDADE

O investimento financeiro deve ter influência limitada.

Criar estrutura preparada para:

Final Score =

Compatibility Score × 0.80

Priority Score × 0.20

IMPORTANTE:

Esses pesos devem ser configuráveis futuramente no painel administrativo.

Não hardcode regras de negócio importantes diretamente nos componentes.

18. JANELA DE CONEXÃO

Cada oportunidade possui:

opens_at;

closes_at.

Exemplo:

5 minutos.

Mostrar countdown real na interface.

Estados:

DRAFT;

OPEN;

SELECTING;

PROFESSIONAL_SELECTED;

PAYMENT_PENDING;

PAID;

CONTACT_UNLOCKED;

CONNECTED;

EXPIRED;

NO_CANDIDATES;

PAYMENT_EXPIRED;

CANCELLED.

Quando o cronômetro zerar:

impedir novas manifestações;

mudar status;

iniciar processo de seleção.

19. PROFISSIONAL SELECIONADO

Mostrar uma tela especial:

💙 Conexão direcionada a você

Texto:

Seu perfil apresentou alta compatibilidade com esta oportunidade.

Exibir:

Compatibilidade:
92%

Investimento de conexão:
R$120

Botão:

Confirmar conexão

Criar prazo para pagamento.

20. CRÉDITOS

Criar carteira do psicólogo.

Exemplo:

Saldo:

R$500

Histórico:

R$500 — Compra de créditos

R$120 — Conexão

R$200 — Compra de créditos

Adicionar botão:

Adicionar créditos

Pacotes sugeridos:

R$100;

R$250;

R$500;

R$1.000.

21. PAGAMENTO

Criar arquitetura preparada para integração com gateway externo.

Inicialmente pode utilizar mock de pagamento.

Fluxo:

PAYMENT_PENDING

↓

PAID

↓

CONTACT_UNLOCKED

Não liberar o contato apenas pelo frontend.

A API/backend deve garantir que os dados identificáveis só sejam retornados se a conexão estiver autorizada.

22. CONEXÃO REALIZADA

Depois do pagamento:

💙 Conexão realizada!

Texto:

Esta pessoa demonstrou interesse em iniciar acompanhamento psicológico.

Agora liberar:

nome;

WhatsApp;

informações autorizadas;

modalidade;

disponibilidade;

necessidade informada;

faixa de investimento;

frequência.

Adicionar botão:

Iniciar conversa no WhatsApp

Abrir:

https://wa.me/

com telefone correspondente.

23. CICLO DA CONEXÃO

Cada conexão deve permitir ao psicólogo atualizar:

Contato ainda não realizado;

Contato realizado;

Consulta agendada;

Paciente iniciou acompanhamento;

Não consegui contato;

Pessoa desistiu;

Não houve compatibilidade.

Criar timeline.

Exemplo:

Conexão realizada

↓

Contato realizado

↓

Consulta agendada

↓

Atendimento iniciado

24. ESTIMATIVA DE ACOMPANHAMENTO

Na oportunidade, criar um card:

Potencial estimado de acompanhamento

Exemplo:

Faixa informada:

R$150–200 por sessão

Frequência:

Semanal

Projeção de 12 meses:

R$7.800–R$10.400

Adicionar obrigatoriamente:

Estimativa baseada nas informações fornecidas pelo usuário. Não representa garantia de contratação, permanência ou faturamento.

Nunca escrever:

Este paciente vale R$10.000.

25. ADMIN

Criar painel administrativo completo.

Menu:

Visão geral;

Leads;

Psicólogos;

Oportunidades;

Conexões;

Marketing;

Campanhas;

Financeiro;

Créditos;

Conversões;

Configurações.

26. DASHBOARD ADMIN

Criar cards:

Investimento em anúncios;

Leads;

CPL;

Leads qualificados;

Oportunidades;

Conexões realizadas;

Receita;

Margem bruta;

Taxa de agendamento;

Taxa de atendimento.

Criar funil:

Leads

↓

Qualificados

↓

Oportunidades

↓

Conexões

↓

Consultas

↓

Atendimentos

27. MARKETING

Preparar estrutura de dados para registrar:

source;

medium;

campaign;

campaign_id;

ad_id;

adset_id;

keyword;

utm_source;

utm_medium;

utm_campaign;

utm_content;

utm_term;

landing_page;

click_id.

Canais:

Google;

Meta;

Instagram;

Facebook;

TikTok;

Orgânico;

Indicação;

Outros.

28. CAC E CPL

O sistema precisa calcular:

CPL

Gasto em campanha / quantidade de leads.

Receita por conexão

Valor pago pelo psicólogo.

Margem bruta da conexão

Receita da conexão - custo atribuído ao lead.

Exemplo:

CAC/Custo atribuído:
R$50

Receita da conexão:
R$120

Margem:
R$70

29. CONVERSÕES

Registrar eventos:

LEAD_CREATED;

LEAD_QUALIFIED;

LEAD_WARMED;

OPPORTUNITY_CREATED;

INTEREST_RECEIVED;

PROFESSIONAL_SELECTED;

PAYMENT_COMPLETED;

CONTACT_UNLOCKED;

CONTACTED;

APPOINTMENT_SCHEDULED;

TREATMENT_STARTED.

Cada evento deve ter:

id;

entidade;

timestamp;

origem;

metadata.

30. WHATSAPP

Criar inicialmente a arquitetura e telas preparadas para integração futura com WhatsApp Business API.

Não implementar nenhuma integração falsa.

Criar serviço abstrato:

WhatsAppProvider

Preparado para:

envio de mensagem;

recebimento;

webhook;

templates;

status de entrega.

Fluxo futuro:

Lead criado

↓

Mensagem automática

↓

Pergunta

↓

Resposta

↓

Atualização do lead

↓

Aquecimento

↓

Ready for Matching

31. AQUECIMENTO

Criar estrutura para automações.

Exemplo:

Mensagem:

Olá, Ana! 💙 Encontramos profissionais que podem ser compatíveis com o que você procura.

Estou verificando disponibilidade e características dos profissionais para apresentar as melhores opções para você.

Depois:

Você gostaria de começar ainda esta semana ou está pesquisando para começar mais adiante?

Resposta deve atualizar o estado do lead.

32. PRIVACIDADE E SEGURANÇA

O sistema trabalha com informações sensíveis.

Portanto:

utilizar autenticação;

autorização por roles;

RLS;

logs de auditoria;

não expor dados de leads;

não enviar dados pessoais no payload de oportunidades;

consentimento explícito;

registro do consentimento;

possibilidade de revogação;

princípio de menor privilégio.

Criar estrutura para:

audit_logs

Com:

actor_id;

action;

entity;

entity_id;

timestamp;

metadata.

33. BANCO DE DADOS

Criar estrutura inicial considerando pelo menos:

users;

psychologists;

psychologist_profiles;

psychologist_specialties;

psychologist_preferences;

psychologist_availability;

leads;

lead_consents;

lead_sources;

lead_events;

connection_profiles;

connection_needs;

connection_availability;

campaigns;

ads;

marketing_costs;

connection_opportunities;

opportunity_candidates;

interest_manifestations;

connections;

connection_events;

wallets;

credit_transactions;

payments;

whatsapp_conversations;

whatsapp_messages;

automation_flows;

conversion_events;

audit_logs.

Usar UUID como IDs.

Adicionar:

created_at;

updated_at;

quando aplicável.

34. RELAÇÃO IMPORTANTE

Não trate estas entidades como iguais:

Lead

≠

Connection Profile

≠

Connection Opportunity

≠

Connection

O Lead é a pessoa captada.

O Connection Profile representa o que ela procura.

A Connection Opportunity representa a oportunidade distribuída aos profissionais.

A Connection representa o vínculo criado após seleção e confirmação.

35. UX DO PSICÓLOGO

A página mais importante é:

Oportunidades

Quero uma experiência rápida.

Quando uma nova oportunidade aparecer, o profissional deve entender em poucos segundos:

o que a pessoa procura;

quando deseja começar;

modalidade;

disponibilidade;

faixa de investimento;

compatibilidade;

quanto tempo resta;

como manifestar interesse.

Não poluir a tela.

36. NOTIFICAÇÕES

Preparar componente de notificações.

Exemplos:

💙 Nova oportunidade compatível

Você recebeu prioridade em uma conexão.

Pagamento confirmado.

Contato desbloqueado.

Sua janela de pagamento termina em 4 minutos.

37. RESPONSIVIDADE

O painel deve funcionar muito bem no celular.

Principalmente:

oportunidades;

manifestação de interesse;

conexão selecionada;

pagamentos;

WhatsApp.

O psicólogo provavelmente utilizará essas áreas pelo smartphone.

38. DADOS DEMONSTRATIVOS

Criar dados fictícios para visualização.

Psicólogos fictícios.

Leads fictícios.

Oportunidades fictícias.

Campanhas fictícias.

Não utilizar números ou pessoas reais.

39. NÃO IMPLEMENTAR AGORA

Não desenvolver ainda:

IA generativa complexa;

machine learning;

integração real com Meta Ads;

integração real com Google Ads;

integração real com TikTok Ads;

integração real com WhatsApp;

sistema de recomendação baseado em ML.

Mas deixe a arquitetura preparada para essas integrações.

40. PRIMEIRA ENTREGA

Nesta primeira execução, quero que você:

crie a arquitetura base;

configure autenticação;

defina os roles;

configure Supabase;

crie as principais tabelas;

configure RLS;

crie a landing page;

crie a pré-qualificação;

crie o dashboard do psicólogo;

crie a página de oportunidades;

crie a tela de manifestação de interesse;

crie a página de conexões;

crie créditos;

crie o painel administrativo;

utilize dados de demonstração para apresentar o fluxo.

Não tente esconder funcionalidades incompletas simulando integrações externas.

Quando algo ainda não estiver integrado, identificar claramente como:

Modo demonstração

ou

Integração pendente

41. PRINCÍPIO CENTRAL

Antes de tomar qualquer decisão de produto, lembre-se:

Não estamos construindo um site de psicólogos.

Estamos construindo:

uma plataforma de aquisição, qualificação, matching e distribuição inteligente de oportunidades de atendimento psicológico.

Para o paciente, a sensação deve ser:

“Finalmente encontrei alguém que pode me ajudar.”

Para o psicólogo:

“Finalmente encontrei pessoas procurando exatamente o tipo de atendimento que eu ofereço.”

Preserve esse conceito durante toda a implementação.

Comece agora pela estrutura da aplicação, banco de dados, autenticação, layout e fluxo principal. Não simplifique as regras principais da plataforma e não transforme o projeto em um CRUD genérico.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
