
-- ENUMS
CREATE TYPE public.app_role AS ENUM ('admin','psychologist');
CREATE TYPE public.lead_status AS ENUM ('NEW','CONSENTED','QUALIFYING','QUALIFIED','WARMING','READY_FOR_MATCHING','OPPORTUNITY_CREATED','CONNECTED','CONVERTED','INVALID','UNRESPONSIVE','CANCELLED');
CREATE TYPE public.opportunity_status AS ENUM ('DRAFT','OPEN','SELECTING','PROFESSIONAL_SELECTED','PAYMENT_PENDING','PAID','CONTACT_UNLOCKED','CONNECTED','EXPIRED','NO_CANDIDATES','PAYMENT_EXPIRED','CANCELLED');
CREATE TYPE public.connection_stage AS ENUM ('CONNECTION_MADE','CONTACT_PENDING','CONTACTED','APPOINTMENT_SCHEDULED','TREATMENT_STARTED','NO_CONTACT','GAVE_UP','NOT_COMPATIBLE');

CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql SET search_path = public;

-- PROFILES
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY,
  full_name TEXT,
  email TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own profile" ON public.profiles FOR ALL TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ROLES
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name', NEW.email)
  ON CONFLICT (id) DO NOTHING;
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'psychologist') ON CONFLICT DO NOTHING;
  INSERT INTO public.psychologist_profiles (user_id, display_name) VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name','Profissional'))
  ON CONFLICT (user_id) DO NOTHING;
  INSERT INTO public.wallets (user_id) VALUES (NEW.id) ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END; $$;

-- PSYCHOLOGISTS
CREATE TABLE public.psychologist_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE,
  display_name TEXT NOT NULL,
  photo_url TEXT,
  crp TEXT,
  crp_state TEXT,
  bio TEXT,
  education TEXT,
  years_experience INT,
  specialties TEXT[] NOT NULL DEFAULT '{}',
  audiences TEXT[] NOT NULL DEFAULT '{}',
  approaches TEXT[] NOT NULL DEFAULT '{}',
  modalities TEXT[] NOT NULL DEFAULT '{}',
  city TEXT,
  state TEXT,
  online_care BOOLEAN NOT NULL DEFAULT true,
  min_price NUMERIC(10,2),
  max_price NUMERIC(10,2),
  availability TEXT[] NOT NULL DEFAULT '{}',
  gender TEXT,
  quality_score INT NOT NULL DEFAULT 70,
  is_demo BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.psychologist_profiles TO authenticated;
GRANT ALL ON public.psychologist_profiles TO service_role;
ALTER TABLE public.psychologist_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own psy profile" ON public.psychologist_profiles FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "admin psy profiles" ON public.psychologist_profiles FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_psy_updated BEFORE UPDATE ON public.psychologist_profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.psychologist_preferences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL,
  needs TEXT[] NOT NULL DEFAULT '{}',
  specialties TEXT[] NOT NULL DEFAULT '{}',
  cities TEXT[] NOT NULL DEFAULT '{}',
  states TEXT[] NOT NULL DEFAULT '{}',
  online_only BOOLEAN NOT NULL DEFAULT false,
  in_person BOOLEAN NOT NULL DEFAULT false,
  price_ranges TEXT[] NOT NULL DEFAULT '{}',
  schedules TEXT[] NOT NULL DEFAULT '{}',
  audiences TEXT[] NOT NULL DEFAULT '{}',
  receive_opportunities BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.psychologist_preferences TO authenticated;
GRANT ALL ON public.psychologist_preferences TO service_role;
ALTER TABLE public.psychologist_preferences ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own prefs" ON public.psychologist_preferences FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_prefs_updated BEFORE UPDATE ON public.psychologist_preferences FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- LEADS (PII) - no anon/authenticated read
CREATE TABLE public.leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name TEXT NOT NULL,
  whatsapp TEXT NOT NULL,
  email TEXT,
  status public.lead_status NOT NULL DEFAULT 'NEW',
  source TEXT,
  medium TEXT,
  campaign TEXT,
  campaign_id TEXT,
  ad_id TEXT,
  adset_id TEXT,
  keyword TEXT,
  utm_source TEXT,
  utm_medium TEXT,
  utm_campaign TEXT,
  utm_content TEXT,
  utm_term TEXT,
  landing_page TEXT,
  click_id TEXT,
  attributed_cost NUMERIC(10,2) NOT NULL DEFAULT 0,
  is_demo BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.leads TO authenticated;
GRANT ALL ON public.leads TO service_role;
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin read leads" ON public.leads FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_leads_updated BEFORE UPDATE ON public.leads FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.lead_consents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  storage_consent BOOLEAN NOT NULL DEFAULT false,
  matching_consent BOOLEAN NOT NULL DEFAULT false,
  sharing_consent BOOLEAN NOT NULL DEFAULT false,
  consent_text TEXT,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.lead_consents TO authenticated;
GRANT ALL ON public.lead_consents TO service_role;
ALTER TABLE public.lead_consents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin read consents" ON public.lead_consents FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.lead_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  from_status public.lead_status,
  to_status public.lead_status,
  note TEXT,
  metadata JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.lead_events TO authenticated;
GRANT ALL ON public.lead_events TO service_role;
ALTER TABLE public.lead_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin read lead events" ON public.lead_events FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));

-- CONNECTION PROFILE (non identifiable)
CREATE TABLE public.connection_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  need TEXT NOT NULL,
  need_details TEXT,
  professional_preference TEXT NOT NULL DEFAULT 'indiferente',
  modality TEXT NOT NULL DEFAULT 'online',
  city TEXT,
  state TEXT,
  availability TEXT[] NOT NULL DEFAULT '{}',
  start_intent TEXT,
  price_range TEXT,
  frequency TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.connection_profiles TO authenticated;
GRANT ALL ON public.connection_profiles TO service_role;
ALTER TABLE public.connection_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin read conn profiles" ON public.connection_profiles FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_cp_updated BEFORE UPDATE ON public.connection_profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- OPPORTUNITIES (safe payload, readable by psychologists)
CREATE TABLE public.connection_opportunities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  connection_profile_id UUID NOT NULL REFERENCES public.connection_profiles(id) ON DELETE CASCADE,
  status public.opportunity_status NOT NULL DEFAULT 'OPEN',
  need TEXT NOT NULL,
  need_details TEXT,
  modality TEXT NOT NULL,
  city TEXT,
  state TEXT,
  professional_preference TEXT,
  availability TEXT[] NOT NULL DEFAULT '{}',
  start_intent TEXT,
  price_range TEXT,
  frequency TEXT,
  base_price NUMERIC(10,2) NOT NULL DEFAULT 80,
  opens_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  closes_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '5 minutes'),
  selected_user_id UUID,
  selected_amount NUMERIC(10,2),
  payment_due_at TIMESTAMPTZ,
  is_demo BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.connection_opportunities TO authenticated;
GRANT ALL ON public.connection_opportunities TO service_role;
ALTER TABLE public.connection_opportunities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "psy read opportunities" ON public.connection_opportunities FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(),'psychologist') OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_opp_updated BEFORE UPDATE ON public.connection_opportunities FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.interest_manifestations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  opportunity_id UUID NOT NULL REFERENCES public.connection_opportunities(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  priority_amount NUMERIC(10,2) NOT NULL,
  compatibility_score INT NOT NULL DEFAULT 0,
  final_score NUMERIC(10,4) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (opportunity_id, user_id)
);
GRANT SELECT ON public.interest_manifestations TO authenticated;
GRANT ALL ON public.interest_manifestations TO service_role;
ALTER TABLE public.interest_manifestations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own manifestations" ON public.interest_manifestations FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));

-- CONNECTIONS
CREATE TABLE public.connections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  opportunity_id UUID NOT NULL REFERENCES public.connection_opportunities(id) ON DELETE CASCADE,
  lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  amount NUMERIC(10,2) NOT NULL,
  compatibility_score INT NOT NULL DEFAULT 0,
  contact_unlocked BOOLEAN NOT NULL DEFAULT false,
  stage public.connection_stage NOT NULL DEFAULT 'CONNECTION_MADE',
  attributed_cost NUMERIC(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.connections TO authenticated;
GRANT ALL ON public.connections TO service_role;
ALTER TABLE public.connections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own connections" ON public.connections FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_conn_updated BEFORE UPDATE ON public.connections FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.connection_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  connection_id UUID NOT NULL REFERENCES public.connections(id) ON DELETE CASCADE,
  stage public.connection_stage NOT NULL,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.connection_events TO authenticated;
GRANT ALL ON public.connection_events TO service_role;
ALTER TABLE public.connection_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read own connection events" ON public.connection_events FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.connections c WHERE c.id = connection_id AND (c.user_id = auth.uid() OR public.has_role(auth.uid(),'admin'))));

-- WALLET / CREDITS / PAYMENTS
CREATE TABLE public.wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE NOT NULL,
  balance NUMERIC(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.wallets TO authenticated;
GRANT ALL ON public.wallets TO service_role;
ALTER TABLE public.wallets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own wallet" ON public.wallets FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_wallet_updated BEFORE UPDATE ON public.wallets FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.credit_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  amount NUMERIC(10,2) NOT NULL,
  kind TEXT NOT NULL,
  description TEXT,
  connection_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.credit_transactions TO authenticated;
GRANT ALL ON public.credit_transactions TO service_role;
ALTER TABLE public.credit_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own credit tx" ON public.credit_transactions FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));

CREATE TABLE public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  connection_id UUID,
  amount NUMERIC(10,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'PAYMENT_PENDING',
  provider TEXT NOT NULL DEFAULT 'demo',
  provider_reference TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.payments TO authenticated;
GRANT ALL ON public.payments TO service_role;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own payments" ON public.payments FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_pay_updated BEFORE UPDATE ON public.payments FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- MARKETING
CREATE TABLE public.campaigns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  channel TEXT NOT NULL,
  external_id TEXT,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.campaigns TO authenticated;
GRANT ALL ON public.campaigns TO service_role;
ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin campaigns" ON public.campaigns FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.marketing_costs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id UUID REFERENCES public.campaigns(id) ON DELETE CASCADE,
  reference_date DATE NOT NULL DEFAULT current_date,
  spend NUMERIC(10,2) NOT NULL DEFAULT 0,
  leads INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.marketing_costs TO authenticated;
GRANT ALL ON public.marketing_costs TO service_role;
ALTER TABLE public.marketing_costs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin costs" ON public.marketing_costs FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.conversion_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id UUID,
  origin TEXT,
  metadata JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.conversion_events TO authenticated;
GRANT ALL ON public.conversion_events TO service_role;
ALTER TABLE public.conversion_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin conversions" ON public.conversion_events FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id UUID,
  metadata JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.audit_logs TO authenticated;
GRANT ALL ON public.audit_logs TO service_role;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin audit" ON public.audit_logs FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));

-- SETTINGS (configurable business rules)
CREATE TABLE public.platform_settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  description TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.platform_settings TO authenticated, anon;
GRANT ALL ON public.platform_settings TO service_role;
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read settings" ON public.platform_settings FOR SELECT TO authenticated, anon USING (true);

INSERT INTO public.platform_settings (key, value, description) VALUES
('matching_weights','{"specialty":25,"modality":15,"availability":15,"price":15,"preferences":10,"location":10,"quality":10}','Pesos do Compatibility Score'),
('final_score_weights','{"compatibility":0.8,"priority":0.2}','Pesos do Final Score'),
('connection_window_seconds','300','Duração da janela de conexão'),
('payment_window_seconds','600','Prazo para confirmação da conexão');

-- WHATSAPP / AUTOMATION (architecture ready, integration pending)
CREATE TABLE public.whatsapp_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES public.leads(id) ON DELETE CASCADE,
  provider TEXT NOT NULL DEFAULT 'pending',
  external_id TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING_INTEGRATION',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.whatsapp_conversations TO authenticated;
GRANT ALL ON public.whatsapp_conversations TO service_role;
ALTER TABLE public.whatsapp_conversations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin wa conv" ON public.whatsapp_conversations FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.whatsapp_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID REFERENCES public.whatsapp_conversations(id) ON DELETE CASCADE,
  direction TEXT NOT NULL,
  body TEXT,
  template TEXT,
  delivery_status TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.whatsapp_messages TO authenticated;
GRANT ALL ON public.whatsapp_messages TO service_role;
ALTER TABLE public.whatsapp_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin wa msg" ON public.whatsapp_messages FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.automation_flows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  trigger_status public.lead_status,
  steps JSONB NOT NULL DEFAULT '[]',
  is_active BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.automation_flows TO authenticated;
GRANT ALL ON public.automation_flows TO service_role;
ALTER TABLE public.automation_flows ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin flows" ON public.automation_flows FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- DEMO DATA
INSERT INTO public.campaigns (id, name, channel, external_id) VALUES
('11111111-1111-4111-8111-111111111111','Ansiedade | Search Brasil','Google','g-001'),
('22222222-2222-4222-8222-222222222222','Terapia Online | Meta Advantage','Meta','m-002'),
('33333333-3333-4333-8333-333333333333','Casal | Instagram Reels','Instagram','i-003');

INSERT INTO public.marketing_costs (campaign_id, reference_date, spend, leads) VALUES
('11111111-1111-4111-8111-111111111111', current_date - 7, 4200, 96),
('22222222-2222-4222-8222-222222222222', current_date - 7, 3100, 82),
('33333333-3333-4333-8333-333333333333', current_date - 7, 1500, 28);

INSERT INTO public.psychologist_profiles (display_name, crp, crp_state, bio, education, years_experience, specialties, audiences, approaches, modalities, city, state, online_care, min_price, max_price, availability, gender, quality_score, is_demo) VALUES
('Marina Alves (demonstração)','06/123456','SP','Atendimento acolhedor com foco em ansiedade e autoestima.','USP',8,'{ansiedade/estresse,autoestima}','{adultos}','{TCC}','{online,presencial}','São Paulo','SP',true,150,220,'{noite,tarde}','feminino',88,true),
('Rafael Souza (demonstração)','04/998877','MG','Terapia de casal e relacionamentos.','UFMG',12,'{relacionamento,"terapia de casal"}','{adultos,casais}','{Sistêmica}','{online}',NULL,'MG',true,180,260,'{noite}','masculino',82,true),
('Camila Torres (demonstração)','05/445566','RJ','Luto, família e questões emocionais.','UFRJ',6,'{luto,família,questões emocionais}','{adultos,adolescentes}','{Psicanálise}','{online,presencial}','Rio de Janeiro','RJ',true,120,180,'{manhã,tarde}','feminino',75,true);

INSERT INTO public.leads (id, first_name, whatsapp, status, source, medium, campaign, utm_source, utm_campaign, landing_page, attributed_cost, is_demo) VALUES
('aaaaaaa1-0000-4000-8000-000000000001','Ana','+5511988887777','READY_FOR_MATCHING','Google','cpc','Ansiedade | Search Brasil','google','ansiedade-search','/', 44, true),
('aaaaaaa1-0000-4000-8000-000000000002','Bruno','+5531977776666','READY_FOR_MATCHING','Meta','paid_social','Terapia Online | Meta Advantage','meta','terapia-online','/', 38, true),
('aaaaaaa1-0000-4000-8000-000000000003','Carla','+5521966665555','QUALIFIED','Instagram','paid_social','Casal | Instagram Reels','instagram','casal-reels','/', 54, true);

INSERT INTO public.lead_consents (lead_id, storage_consent, matching_consent, sharing_consent, consent_text) VALUES
('aaaaaaa1-0000-4000-8000-000000000001',true,true,true,'Consentimento de demonstração'),
('aaaaaaa1-0000-4000-8000-000000000002',true,true,true,'Consentimento de demonstração'),
('aaaaaaa1-0000-4000-8000-000000000003',true,true,true,'Consentimento de demonstração');

INSERT INTO public.connection_profiles (id, lead_id, need, professional_preference, modality, city, state, availability, start_intent, price_range, frequency) VALUES
('bbbbbbb1-0000-4000-8000-000000000001','aaaaaaa1-0000-4000-8000-000000000001','ansiedade/estresse','psicóloga mulher','online','São Paulo','SP','{noite}','esta semana','R$150–200','semanal'),
('bbbbbbb1-0000-4000-8000-000000000002','aaaaaaa1-0000-4000-8000-000000000002','relacionamento','indiferente','online','Belo Horizonte','MG','{noite,finais de semana}','agora','R$200–300','quinzenal'),
('bbbbbbb1-0000-4000-8000-000000000003','aaaaaaa1-0000-4000-8000-000000000003','terapia de casal','indiferente','presencial','Rio de Janeiro','RJ','{tarde}','próximas semanas','R$150–200','semanal');

INSERT INTO public.connection_opportunities (connection_profile_id, status, need, modality, city, state, professional_preference, availability, start_intent, price_range, frequency, base_price, opens_at, closes_at, is_demo) VALUES
('bbbbbbb1-0000-4000-8000-000000000001','OPEN','ansiedade/estresse','online','São Paulo','SP','psicóloga mulher','{noite}','esta semana','R$150–200','semanal',80, now(), now() + interval '5 minutes', true),
('bbbbbbb1-0000-4000-8000-000000000002','OPEN','relacionamento','online','Belo Horizonte','MG','indiferente','{noite,finais de semana}','agora','R$200–300','quinzenal',100, now(), now() + interval '9 minutes', true),
('bbbbbbb1-0000-4000-8000-000000000003','OPEN','terapia de casal','presencial','Rio de Janeiro','RJ','indiferente','{tarde}','próximas semanas','R$150–200','semanal',90, now(), now() + interval '14 minutes', true);

INSERT INTO public.conversion_events (event_type, entity, entity_id, origin) VALUES
('LEAD_CREATED','lead','aaaaaaa1-0000-4000-8000-000000000001','demo'),
('LEAD_QUALIFIED','lead','aaaaaaa1-0000-4000-8000-000000000001','demo'),
('OPPORTUNITY_CREATED','opportunity',NULL,'demo');
